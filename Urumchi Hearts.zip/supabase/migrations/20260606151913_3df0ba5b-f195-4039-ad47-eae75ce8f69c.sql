
CREATE TABLE public.yuki_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  administration_id TEXT NOT NULL,
  administration_name TEXT,
  access_key_last8 TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  authorized_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_sync_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.yuki_sync_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_id UUID REFERENCES public.yuki_connections(id) ON DELETE SET NULL,
  file_name TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'yuki_oauth',
  status TEXT NOT NULL DEFAULT 'pending',
  rows_received INT NOT NULL DEFAULT 0,
  rows_processed INT NOT NULL DEFAULT 0,
  rows_failed INT NOT NULL DEFAULT 0,
  total_debet NUMERIC(18,2) NOT NULL DEFAULT 0,
  total_credit NUMERIC(18,2) NOT NULL DEFAULT 0,
  period_start DATE,
  period_end DATE,
  error_message TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

CREATE TABLE public.yuki_ledger_entries (
  id BIGSERIAL PRIMARY KEY,
  sync_run_id UUID NOT NULL REFERENCES public.yuki_sync_runs(id) ON DELETE CASCADE,
  rekening INT,
  periode DATE,
  boekdatum DATE,
  boeknummer TEXT,
  trek TEXT,
  debet NUMERIC(18,2),
  credit NUMERIC(18,2),
  boekingstekst TEXT,
  dagboek TEXT,
  btw NUMERIC(18,2),
  btw_srt TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ledger_run ON public.yuki_ledger_entries(sync_run_id);
CREATE INDEX idx_ledger_period ON public.yuki_ledger_entries(periode);
CREATE INDEX idx_sync_started ON public.yuki_sync_runs(started_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.yuki_connections TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.yuki_sync_runs TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.yuki_ledger_entries TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.yuki_ledger_entries_id_seq TO anon, authenticated;
GRANT ALL ON public.yuki_connections TO service_role;
GRANT ALL ON public.yuki_sync_runs TO service_role;
GRANT ALL ON public.yuki_ledger_entries TO service_role;
GRANT ALL ON SEQUENCE public.yuki_ledger_entries_id_seq TO service_role;

ALTER TABLE public.yuki_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.yuki_sync_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.yuki_ledger_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "demo_open_all_conn" ON public.yuki_connections FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "demo_open_all_runs" ON public.yuki_sync_runs FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "demo_open_all_entries" ON public.yuki_ledger_entries FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
