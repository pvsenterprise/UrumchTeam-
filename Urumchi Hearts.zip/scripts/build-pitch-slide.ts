import PptxGenJS from "pptxgenjs";

const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_WIDE"; // 13.333 x 7.5
pptx.title = "Urumchi — Altis Treasury Intelligence";

const NAVY = "1E2761";
const ICE = "CADCFC";
const CORAL = "F96167";
const INK = "0F1535";
const MUTED = "5B6478";
const CARD_BG = "F7F8FC";

const slide = pptx.addSlide();
slide.background = { color: "FFFFFF" };

// Top navy band
slide.addShape("rect", { x: 0, y: 0, w: 13.333, h: 0.55, fill: { color: NAVY } });
slide.addText("URUMCHI  ·  ALTIS TREASURY INTELLIGENCE", {
  x: 0.5, y: 0, w: 8, h: 0.55,
  fontFace: "Georgia", fontSize: 16, bold: true, color: "FFFFFF", valign: "middle",
  charSpacing: 4,
});
slide.addText("CFO Pitch · Team Urumchi", {
  x: 4.833, y: 0, w: 8, h: 0.55,
  fontFace: "Calibri", fontSize: 12, color: ICE, valign: "middle", align: "right",
});

// Kicker
slide.addText("THE CFO'S MONDAY-MORNING QUESTION", {
  x: 0.5, y: 0.85, w: 12.333, h: 0.3,
  fontFace: "Calibri", fontSize: 13, bold: true, color: MUTED, charSpacing: 6,
});

// Headline
slide.addText('"Will we breach the €250k covenant in the next 13 weeks?"', {
  x: 0.5, y: 1.2, w: 12.333, h: 1.0,
  fontFace: "Georgia", fontSize: 28, bold: true, color: INK, italic: true,
});

// Two columns
const cardY = 2.5;
const cardH = 3.2;

// PAIN card
slide.addShape("roundRect", {
  x: 0.5, y: cardY, w: 5.8, h: cardH,
  fill: { color: CARD_BG }, line: { color: "E2E5EE", width: 1 }, rectRadius: 0.1,
});
slide.addText("THE PAIN", {
  x: 0.85, y: cardY + 0.25, w: 5, h: 0.3,
  fontFace: "Calibri", fontSize: 12, bold: true, color: CORAL, charSpacing: 6,
});
slide.addText(
  [
    { text: "Yuki GL stuck in spreadsheets", options: { bullet: { code: "25A0" }, breakLine: true } },
    { text: "Weather wipes working days — silently kills revenue", options: { bullet: { code: "25A0" }, breakLine: true } },
    { text: "Covenant breaches spotted weeks too late", options: { bullet: { code: "25A0" }, breakLine: true } },
    { text: "PE board asks for a 13-week view; Excel takes 2 days", options: { bullet: { code: "25A0" } } },
  ],
  {
    x: 0.85, y: cardY + 0.7, w: 5.15, h: cardH - 0.9,
    fontFace: "Calibri", fontSize: 17, color: INK, paraSpaceAfter: 10, valign: "top",
  },
);

// COPILOT card
slide.addShape("roundRect", {
  x: 6.55, y: cardY, w: 6.28, h: cardH,
  fill: { color: ICE }, line: { color: NAVY, width: 1 }, rectRadius: 0.1,
});
slide.addText("THE COPILOT", {
  x: 6.9, y: cardY + 0.25, w: 5.5, h: 0.3,
  fontFace: "Calibri", fontSize: 12, bold: true, color: NAVY, charSpacing: 6,
});
slide.addText(
  [
    { text: "Yuki OAuth → live 13-week cash forecast", options: { bullet: { code: "25A0" }, breakLine: true } },
    { text: "Open-Meteo weather drag, per region", options: { bullet: { code: "25A0" }, breakLine: true } },
    { text: "AI CFO briefing: trough, risk, action", options: { bullet: { code: "25A0" } } },
  ],
  {
    x: 6.9, y: cardY + 0.7, w: 5.6, h: 1.7,
    fontFace: "Calibri", fontSize: 15, color: INK, paraSpaceAfter: 4, valign: "top",
  },
);

// Stat callout inside copilot card
slide.addShape("rect", {
  x: 6.9, y: cardY + 1.95, w: 5.6, h: 0.02, fill: { color: NAVY }, line: { color: NAVY, width: 0 },
});
slide.addText("€312k · W7", {
  x: 6.9, y: cardY + 2.1, w: 5.6, h: 0.55,
  fontFace: "Georgia", fontSize: 30, bold: true, color: CORAL,
});
slide.addText("Cash trough · Action: draw RCF before W7", {
  x: 6.9, y: cardY + 2.7, w: 5.6, h: 0.3,
  fontFace: "Calibri", fontSize: 13, color: NAVY,
});

// Demo strip
slide.addText(
  [
    { text: "LIVE DEMO   ", options: { bold: true, color: NAVY, charSpacing: 4 } },
    { text: "Scenario toggle: base · stress · adverse weather · custom replay", options: { color: MUTED } },
  ],
  {
    x: 0.5, y: cardY + cardH + 0.25, w: 12.333, h: 0.35,
    fontFace: "Calibri", fontSize: 14,
  },
);

// Footer band
slide.addShape("rect", { x: 0, y: 7.0, w: 13.333, h: 0.5, fill: { color: NAVY } });
slide.addText("Team Urumchi  ·  Ziya Alim Sungkar  ·  Prateek Vivek Samarth  ·  Abdulhabir Karahanli", {
  x: 0.5, y: 7.0, w: 9, h: 0.5,
  fontFace: "Calibri", fontSize: 12, color: "FFFFFF", valign: "middle",
});
slide.addText("Built on Lovable Cloud · Yuki · Open-Meteo", {
  x: 8, y: 7.0, w: 4.833, h: 0.5,
  fontFace: "Calibri", fontSize: 11, color: ICE, italic: true, valign: "middle", align: "right",
});

await pptx.writeFile({ fileName: "/mnt/documents/urumchi_pitch.pptx" });
console.log("wrote /mnt/documents/urumchi_pitch.pptx");
