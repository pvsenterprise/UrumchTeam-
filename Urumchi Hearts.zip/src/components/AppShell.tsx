import { Link, Outlet } from "@tanstack/react-router";
import { Building2, LineChart, Cloud, Plug } from "lucide-react";

export function AppShell() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-sidebar">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between px-8 py-4">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-sm bg-primary text-primary-foreground">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Altis Groep</div>
              <div className="font-serif text-lg font-semibold leading-none">Treasury Intelligence</div>
            </div>
          </Link>
          <nav className="flex items-center gap-1">
            <NavLink to="/forecast" icon={<LineChart className="h-4 w-4" />} label="CFO Dashboard" />
            <NavLink to="/weather" icon={<Cloud className="h-4 w-4" />} label="Site Conditions" />
            <NavLink to="/connect-yuki" icon={<Plug className="h-4 w-4" />} label="Connect Yuki" />
          </nav>
          <div className="flex items-center gap-3" />
        </div>
      </header>
      <main className="mx-auto max-w-[1600px] px-8 py-8">
        <Outlet />
      </main>
      <footer className="border-t border-border py-6">
        <div className="mx-auto max-w-[1600px] px-8 text-xs text-muted-foreground">
          Altis Groep · PE Treasury Console · Data: Yuki GL · Weather: KNMI / Open-Meteo
        </div>
      </footer>
    </div>
  );
}

function NavLink({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-2 rounded-sm px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground [&.active]:bg-accent [&.active]:text-primary"
      activeOptions={{ exact: to === "/" }}
    >
      {icon}
      {label}
    </Link>
  );
}
