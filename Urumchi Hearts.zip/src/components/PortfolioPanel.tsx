import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from "recharts";
import {
  dataset,
  months,
  revenue,
  collections as collectionsFor,
  formatEUR,
  monthLabel,
  type Region,
} from "@/lib/altis-data";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowDownRight, ArrowUpRight, FileText, Receipt, Wallet } from "lucide-react";

type DrillTarget =
  | { kind: "revenue"; ym: string; region: Exclude<Region, "Company">; amount: number }
  | { kind: "revenue-company"; ym: string; amount: number }
  | { kind: "collections"; ym: string; amount: number };

interface Props {
  region: Region;
}

const COLOR_ANDIJK = "oklch(0.78 0.13 85)";
const COLOR_WINSCHOTEN = "oklch(0.65 0.15 220)";
const COLOR_COLLECTIONS = "oklch(0.70 0.14 160)";

export function PortfolioPanel({ region }: Props) {
  const [drill, setDrill] = useState<DrillTarget | null>(null);

  const data = useMemo(() => {
    return months.map((m) => {
      const andijk = revenue("Andijk", m);
      const winschoten = revenue("Winschoten", m);
      const companyRev = revenue("Company", m);
      const coll = collectionsFor(m);
      return {
        ym: m,
        label: monthLabel(m),
        Andijk: Math.round(andijk),
        Winschoten: Math.round(winschoten),
        Company: Math.round(companyRev),
        Collections: Math.round(coll),
      };
    });
  }, []);

  const totalRev = data.reduce((a, b) => a + (region === "Company" ? b.Company : region === "Andijk" ? b.Andijk : b.Winschoten), 0);
  const totalColl = data.reduce((a, b) => a + b.Collections, 0);
  const realisation = totalRev > 0 ? (totalColl / data.reduce((a, b) => a + b.Company, 0)) * 100 : 0;

  // YoY (calendar-year totals)
  const yearTotals = useMemo(() => {
    const m = new Map<string, number>();
    data.forEach((d) => {
      const y = d.ym.slice(0, 4);
      const v = region === "Company" ? d.Company : region === "Andijk" ? d.Andijk : d.Winschoten;
      m.set(y, (m.get(y) ?? 0) + v);
    });
    return Array.from(m.entries()).sort();
  }, [data, region]);
  const yoy = yearTotals.length >= 2
    ? ((yearTotals[yearTotals.length - 1][1] - yearTotals[yearTotals.length - 2][1]) / yearTotals[yearTotals.length - 2][1]) * 100
    : 0;

  const peakMonth = useMemo(() => {
    let best = data[0];
    for (const d of data) {
      const v = region === "Company" ? d.Company : region === "Andijk" ? d.Andijk : d.Winschoten;
      const bestV = region === "Company" ? best.Company : region === "Andijk" ? best.Andijk : best.Winschoten;
      if (v > bestV) best = d;
    }
    return best;
  }, [data, region]);

  const handleBarClick = (entry: any, datakey: string) => {
    if (!entry) return;
    const ym = entry.ym;
    if (datakey === "Andijk") setDrill({ kind: "revenue", ym, region: "Andijk", amount: entry.Andijk });
    else if (datakey === "Winschoten") setDrill({ kind: "revenue", ym, region: "Winschoten", amount: entry.Winschoten });
  };

  return (
    <div className="rounded-md border border-border bg-card">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-border px-6 py-5">
        <div>
          <div className="text-xs uppercase tracking-[0.25em] text-primary">Portfolio Performance</div>
          <div className="mt-1 font-serif text-2xl font-semibold">Revenue & Collections</div>
          <div className="mt-1 text-xs text-muted-foreground">
            Reconciled Yuki GL · {months[0]} → {months[months.length - 1]} · click any bar or collection dot to inspect line-item transactions
          </div>
        </div>
        <div className="flex flex-wrap gap-3">
          <Stat label="Total Revenue" sub={`${region} · ${data.length} mo`} value={formatEUR(totalRev)} tone="primary" />
          <Stat label="Collections" sub="Net cash in" value={formatEUR(totalColl)} tone="emerald" />
          <Stat label="Realisation" sub="Coll / Co. Rev" value={`${realisation.toFixed(1)}%`} tone="neutral" />
          <Stat
            label="YoY"
            sub={yearTotals.length >= 2 ? `${yearTotals[yearTotals.length - 1][0]} vs ${yearTotals[yearTotals.length - 2][0]}` : "—"}
            value={`${yoy >= 0 ? "+" : ""}${yoy.toFixed(1)}%`}
            tone={yoy >= 0 ? "primary" : "destructive"}
            icon={yoy >= 0 ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
          />
        </div>
      </div>

      <div className="h-[420px] px-2 py-4">
        <ResponsiveContainer>
          <ComposedChart data={data} margin={{ top: 16, right: 24, bottom: 8, left: 8 }}>
            <defs>
              <linearGradient id="grad-andijk" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={COLOR_ANDIJK} stopOpacity={0.95} />
                <stop offset="100%" stopColor={COLOR_ANDIJK} stopOpacity={0.55} />
              </linearGradient>
              <linearGradient id="grad-winschoten" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={COLOR_WINSCHOTEN} stopOpacity={0.95} />
                <stop offset="100%" stopColor={COLOR_WINSCHOTEN} stopOpacity={0.55} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.30 0.03 260)" vertical={false} />
            <XAxis dataKey="label" stroke="oklch(0.72 0.025 80)" fontSize={10} interval={1} tick={{ fill: "oklch(0.72 0.025 80)" }} />
            <YAxis stroke="oklch(0.72 0.025 80)" fontSize={11} tickFormatter={(v) => formatEUR(v)} />
            <Tooltip
              cursor={{ fill: "oklch(0.30 0.03 260 / 0.25)" }}
              contentStyle={{
                backgroundColor: "oklch(0.18 0.035 260)",
                border: "1px solid oklch(0.30 0.03 260)",
                borderRadius: 6,
                fontSize: 12,
              }}
              labelStyle={{ color: "oklch(0.85 0.02 80)", fontWeight: 600, marginBottom: 4 }}
              formatter={(v: number, name: string) => [formatEUR(v), name]}
            />
            <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} iconType="circle" />
            <ReferenceLine
              y={data.reduce((a, b) => a + b.Company, 0) / data.length}
              stroke="oklch(0.55 0.10 290)"
              strokeDasharray="4 4"
              label={{ value: "Avg", position: "right", fill: "oklch(0.72 0.025 80)", fontSize: 10 }}
            />
            {(region === "Company" || region === "Andijk") && (
              <Bar
                dataKey="Andijk"
                stackId="rev"
                fill="url(#grad-andijk)"
                cursor="pointer"
                radius={region === "Andijk" ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                onClick={(e: any) => handleBarClick(e?.payload ?? e, "Andijk")}
              />
            )}
            {(region === "Company" || region === "Winschoten") && (
              <Bar
                dataKey="Winschoten"
                stackId="rev"
                fill="url(#grad-winschoten)"
                cursor="pointer"
                radius={[4, 4, 0, 0]}
                onClick={(e: any) => handleBarClick(e?.payload ?? e, "Winschoten")}
              />
            )}
            <Line
              type="monotone"
              dataKey="Collections"
              stroke={COLOR_COLLECTIONS}
              strokeWidth={2.5}
              dot={{ r: 4, fill: COLOR_COLLECTIONS, cursor: "pointer" } as any}
              activeDot={
                {
                  r: 6,
                  cursor: "pointer",
                  onClick: (_e: unknown, payload: any) => {
                    const p = payload?.payload ?? payload;
                    if (p?.ym) {
                      setDrill({ kind: "collections", ym: p.ym, amount: p.Collections });
                    }
                  },
                } as any
              }
            />

          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 gap-px border-t border-border bg-border md:grid-cols-3">
        <FactRow
          icon={<Receipt className="h-4 w-4" />}
          label="Peak month"
          value={`${monthLabel(peakMonth.ym)} · ${formatEUR(region === "Company" ? peakMonth.Company : region === "Andijk" ? peakMonth.Andijk : peakMonth.Winschoten)}`}
        />
        <FactRow icon={<Wallet className="h-4 w-4" />} label="Avg monthly revenue" value={formatEUR(totalRev / data.length)} />
        <FactRow icon={<FileText className="h-4 w-4" />} label="Source" value={`${dataset.transactions.length.toLocaleString()} GL line items archived`} />
      </div>

      <TransactionDrill target={drill} onClose={() => setDrill(null)} />
    </div>
  );
}

function Stat({
  label,
  sub,
  value,
  tone,
  icon,
}: {
  label: string;
  sub: string;
  value: string;
  tone: "primary" | "emerald" | "destructive" | "neutral";
  icon?: React.ReactNode;
}) {
  const color =
    tone === "primary"
      ? "text-primary"
      : tone === "emerald"
        ? "text-emerald-400"
        : tone === "destructive"
          ? "text-destructive"
          : "text-foreground";
  return (
    <div className="min-w-[140px] rounded-sm border border-border bg-muted/30 px-4 py-2">
      <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
        <span>{label}</span>
        {icon && <span className={color}>{icon}</span>}
      </div>
      <div className={`mt-0.5 font-mono text-lg font-semibold ${color}`}>{value}</div>
      <div className="text-[10px] text-muted-foreground">{sub}</div>
    </div>
  );
}

function FactRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 bg-card px-6 py-3 text-xs">
      <span className="text-primary">{icon}</span>
      <span className="uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className="ml-auto font-mono text-foreground">{value}</span>
    </div>
  );
}

function TransactionDrill({ target, onClose }: { target: DrillTarget | null; onClose: () => void }) {
  const rows = useMemo(() => {
    if (!target) return [];
    if (target.kind === "collections") {
      const sourceRows = dataset.transactions.filter((t) => t.date.startsWith(target.ym));
      const sourceTotal = sourceRows.reduce((a, b) => a + b.amount, 0);
      const collectionFactor = sourceTotal ? target.amount / sourceTotal : 0;
      return sourceRows.map((t) => ({
        ...t,
        amount: t.amount * collectionFactor,
        description: `${t.description} · collection contribution from source ledger line`,
      }));
    }
    if (target.kind === "revenue") {
      return dataset.transactions.filter((t) => t.date.startsWith(target.ym) && t.region === target.region);
    }
    return dataset.transactions.filter((t) => t.date.startsWith(target.ym));
  }, [target]);

  const totalAmt = rows.reduce((a, b) => a + b.amount, 0);

  const byAccount = useMemo(() => {
    const m = new Map<string, { count: number; sum: number }>();
    rows.forEach((r) => {
      const e = m.get(r.account) ?? { count: 0, sum: 0 };
      e.count += 1;
      e.sum += r.amount;
      m.set(r.account, e);
    });
    return Array.from(m.entries()).sort((a, b) => b[1].sum - a[1].sum);
  }, [rows]);

  if (!target) return null;

  const headlineLabel =
    target.kind === "revenue"
      ? `${target.region} · Revenue · ${monthLabel(target.ym)}`
      : target.kind === "collections"
        ? `Collections · ${monthLabel(target.ym)}`
        : `Company · Revenue · ${monthLabel(target.ym)}`;

  const yukiAmount = target.amount;
  const reconcileDelta = yukiAmount - totalAmt;
  const hasTx = rows.length > 0;

  return (
    <Dialog open={!!target} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-5xl border-border bg-card text-foreground">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-3 font-serif text-2xl">
            {headlineLabel}
            <span className="rounded-sm border border-primary/40 bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              Yuki: {formatEUR(yukiAmount)}
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-3 gap-3 text-xs">
          <ReconRow label="Line items" value={rows.length.toLocaleString()} />
          <ReconRow label="Sum of lines" value={formatEUR(totalAmt)} />
          <ReconRow
            label="Variance vs Yuki"
            value={`${reconcileDelta >= 0 ? "+" : ""}${formatEUR(reconcileDelta)}`}
            tone={Math.abs(reconcileDelta) < Math.max(yukiAmount * 0.05, 5000) ? "good" : "warn"}
          />
        </div>

        {target.kind === "collections" && (
          <div className="rounded-sm border border-primary/30 bg-primary/5 p-3 text-xs text-muted-foreground">
            Each row is from the uploaded ledger files for {monthLabel(target.ym)}. The Amount column shows the exact contribution used in the collections metric, so these line items tie back to the chart total.
          </div>
        )}

        {byAccount.length > 0 && (
          <div className="rounded-sm border border-border">
            <div className="border-b border-border bg-muted/30 px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground">
              GL accounts in scope
            </div>
            <table className="w-full text-xs">
              <tbody>
                {byAccount.map(([acc, info]) => (
                  <tr key={acc} className="border-t border-border/50 first:border-t-0">
                    <td className="px-3 py-1.5 text-muted-foreground">{acc}</td>
                    <td className="px-3 py-1.5 text-right font-mono text-muted-foreground">{info.count} lines</td>
                    <td className="px-3 py-1.5 text-right font-mono">{formatEUR(info.sum)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="max-h-[420px] overflow-auto rounded-sm border border-border">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-muted text-muted-foreground">
              <tr>
                <th className="px-3 py-2 text-left">Date</th>
                <th className="px-3 py-2 text-left">Region</th>
                <th className="px-3 py-2 text-left">Account</th>
                <th className="px-3 py-2 text-left">Description</th>
                <th className="px-3 py-2 text-left">Journal</th>
                <th className="px-3 py-2 text-left">Voucher</th>
                <th className="px-3 py-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {!hasTx ? (
                <tr>
                  <td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">
                    No matching source ledger line items were found for {monthLabel(target.ym)}.
                  </td>
                </tr>
              ) : (
                rows.map((t, i) => (
                  <tr key={i} className="border-t border-border/40 hover:bg-muted/40">
                    <td className="px-3 py-1.5 font-mono">{t.date}</td>
                    <td className="px-3 py-1.5">{t.region}</td>
                    <td className="px-3 py-1.5 text-muted-foreground">{t.account}</td>
                    <td className="px-3 py-1.5 text-muted-foreground">{t.description}</td>
                    <td className="px-3 py-1.5 font-mono text-muted-foreground">{t.journal}</td>
                    <td className="px-3 py-1.5 font-mono text-muted-foreground">{t.voucher}</td>
                    <td className={`px-3 py-1.5 text-right font-mono ${t.amount >= 0 ? "text-primary" : "text-destructive"}`}>
                      {formatEUR(t.amount)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ReconRow({ label, value, tone }: { label: string; value: string; tone?: "good" | "warn" }) {
  const color = tone === "good" ? "text-primary" : tone === "warn" ? "text-chart-4" : "text-foreground";
  return (
    <div className="rounded-sm border border-border bg-muted/30 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-0.5 font-mono text-base ${color}`}>{value}</div>
    </div>
  );
}
