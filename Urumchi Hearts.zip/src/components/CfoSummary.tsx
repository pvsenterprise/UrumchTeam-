import { useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, AlertTriangle, CloudRain, TrendingDown, Copy, RotateCw, Loader2, FileText } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { formatEUR } from "@/lib/altis-data";
import type { SummaryFacts } from "@/lib/cfo-summary";
import { generateCfoBriefing } from "@/lib/cfo-summary.functions";

interface CfoSummaryProps {
  facts: SummaryFacts;
}

function Tile({
  icon: Icon,
  label,
  value,
  sub,
  tone = "neutral",
  large = false,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub: string;
  tone?: "neutral" | "warn" | "bad";
  large?: boolean;
}) {
  const toneClass =
    tone === "bad"
      ? "border-destructive/40 bg-destructive/5"
      : tone === "warn"
        ? "border-amber-500/30 bg-amber-500/5"
        : "border-border bg-card";
  const accent =
    tone === "bad" ? "text-destructive" : tone === "warn" ? "text-amber-400" : "text-primary";

  return (
    <div className={`flex items-start gap-3 rounded-md border ${toneClass} px-4 py-3`}>
      <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${accent}`} />
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
        <div className={`mt-0.5 font-mono font-semibold ${large ? "text-2xl" : "text-lg"} text-foreground`}>{value}</div>
        <div className="mt-0.5 text-xs text-muted-foreground">{sub}</div>
      </div>
    </div>
  );
}

export function CfoSummary({ facts }: CfoSummaryProps) {
  const [open, setOpen] = useState(false);

  const troughTone = facts.trough.belowCovenant ? "bad" : facts.trough.headroom < 50_000 ? "warn" : "neutral";
  const riskTone = facts.topRiskWeek.netCashFlow < -25_000 ? "bad" : facts.topRiskWeek.netCashFlow < 0 ? "warn" : "neutral";

  const generate = useServerFn(generateCfoBriefing);
  const cacheKey = useMemo(
    () => `${facts.region}|${facts.scenarioLabel}|${facts.trough.weekIdx}|${facts.topRiskWeek.weekIdx}`,
    [facts.region, facts.scenarioLabel, facts.trough.weekIdx, facts.topRiskWeek.weekIdx],
  );
  const [cache, setCache] = useState<Record<string, string>>({});

  const mutation = useMutation({
    mutationFn: async () => generate({ data: { facts } }),
    onSuccess: (res) => {
      if (res.narrative) setCache((c) => ({ ...c, [cacheKey]: res.narrative! }));
      if (res.error) toast.error(res.error);
    },
    onError: () => toast.error("Could not reach the AI service."),
  });

  const handleOpen = (next: boolean) => {
    setOpen(next);
    if (next && !cache[cacheKey] && !mutation.isPending) {
      mutation.mutate();
    }
  };

  const narrative = cache[cacheKey] ?? null;
  const generatedAt = useMemo(() => new Date().toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }), [narrative]);

  return (
    <>
      <div className="rounded-md border border-primary/30 bg-gradient-to-r from-primary/5 via-card to-card px-5 py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <div className="text-xs uppercase tracking-[0.3em] text-primary">Executive Summary</div>
          </div>
          <Button size="sm" variant="default" onClick={() => handleOpen(true)} className="gap-2">
            <FileText className="h-4 w-4" />
            Open briefing
          </Button>
        </div>
        <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-3">
          <Tile
            icon={TrendingDown}
            label="Cash trough"
            value={`${formatEUR(facts.trough.amount)} · W${facts.trough.weekIdx}`}
            sub={
              facts.trough.belowCovenant
                ? `${formatEUR(facts.trough.headroom)} below €250k covenant`
                : `+${formatEUR(facts.trough.headroom)} headroom vs €250k`
            }
            tone={troughTone}
          />
          <Tile
            icon={AlertTriangle}
            label="Top risk week"
            value={`W${facts.topRiskWeek.weekIdx} · ${formatEUR(facts.topRiskWeek.netCashFlow)}`}
            sub={facts.recommendedAction}
            tone={riskTone}
          />
          <Tile
            icon={CloudRain}
            label="Weather drag"
            value={`${facts.weatherDrag.adverseDays} adv. days`}
            sub={`${formatEUR(facts.weatherDrag.revenueImpact)} revenue impact`}
            tone="warn"
          />
        </div>
      </div>

      <Dialog open={open} onOpenChange={handleOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-serif text-2xl">
              <Sparkles className="h-5 w-5 text-primary" />
              CFO Briefing
            </DialogTitle>
            <DialogDescription>
              {facts.region} · {facts.scenarioLabel} · generated {generatedAt}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-5">
            <div className="rounded-md border border-border bg-muted/30 p-4">
              {mutation.isPending && !narrative ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Generating narrative…
                </div>
              ) : narrative ? (
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-foreground/95">{narrative}</p>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No narrative yet. Click <span className="font-medium">Regenerate</span> to retry.
                </p>
              )}
              <div className="mt-3 flex items-center gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => mutation.mutate()}
                  disabled={mutation.isPending}
                  className="gap-1.5"
                >
                  {mutation.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCw className="h-3.5 w-3.5" />}
                  Regenerate
                </Button>
                {narrative && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      navigator.clipboard.writeText(narrative);
                      toast.success("Briefing copied");
                    }}
                    className="gap-1.5"
                  >
                    <Copy className="h-3.5 w-3.5" />
                    Copy
                  </Button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              <Tile
                icon={TrendingDown}
                label="Cash trough"
                value={`${formatEUR(facts.trough.amount)} · W${facts.trough.weekIdx}`}
                sub={
                  facts.trough.belowCovenant
                    ? `${formatEUR(facts.trough.headroom)} below €250k covenant`
                    : `+${formatEUR(facts.trough.headroom)} headroom vs €250k`
                }
                tone={troughTone}
                large
              />
              <Tile
                icon={AlertTriangle}
                label="Top risk week"
                value={`W${facts.topRiskWeek.weekIdx} · ${formatEUR(facts.topRiskWeek.netCashFlow)}`}
                sub={`${facts.topRiskWeek.badWeatherDays}/${facts.topRiskWeek.workingDays} adverse days`}
                tone={riskTone}
                large
              />
              <Tile
                icon={CloudRain}
                label="Weather drag"
                value={`${facts.weatherDrag.adverseDays} adv. days`}
                sub={`${formatEUR(facts.weatherDrag.revenueImpact)} revenue impact`}
                tone="warn"
                large
              />
            </div>

            <div>
              <div className="mb-2 text-xs uppercase tracking-[0.18em] text-muted-foreground">
                Top 3 risk weeks
              </div>
              <div className="overflow-hidden rounded-md border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 text-left">Week</th>
                      <th className="px-3 py-2 text-left">Starts</th>
                      <th className="px-3 py-2 text-right">Net cash</th>
                      <th className="px-3 py-2 text-right">Cumulative</th>
                      <th className="px-3 py-2 text-right">Adverse / Working</th>
                    </tr>
                  </thead>
                  <tbody>
                    {facts.riskWeeks.map((w) => (
                      <tr key={w.weekIdx} className="border-t border-border">
                        <td className="px-3 py-2 font-medium">W{w.weekIdx}</td>
                        <td className="px-3 py-2 font-mono text-xs text-muted-foreground">{w.weekStart}</td>
                        <td className={`px-3 py-2 text-right font-mono ${w.netCashFlow < 0 ? "text-destructive" : ""}`}>
                          {formatEUR(w.netCashFlow)}
                        </td>
                        <td className="px-3 py-2 text-right font-mono">{formatEUR(w.cumulativeCash)}</td>
                        <td className="px-3 py-2 text-right font-mono text-xs">
                          {w.badWeatherDays} / {w.workingDays}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="rounded-md border-l-4 border-primary bg-primary/5 px-4 py-3 text-sm">
              <span className="font-medium text-primary">Recommended action:</span>{" "}
              {facts.recommendedAction}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
