import raw from "@/data/altis.json";
import { isAdverseDay } from "@/lib/weather";

export type MonthlyRecord = Record<string, number>;
export type Region = "Company" | "Andijk" | "Winschoten";

export interface Dataset {
  company: Record<string, MonthlyRecord>;
  andijk: Record<string, MonthlyRecord>;
  winschoten: Record<string, MonthlyRecord>;
  transactions: Array<{
    date: string;
    region: string;
    account: string;
    amount: number;
    description: string;
    journal: string;
    voucher: string;
  }>;
}

export const dataset = raw as unknown as Dataset;

export const months = Object.keys(dataset.company).sort();

function sumRecord(r: MonthlyRecord | undefined): number {
  if (!r) return 0;
  return Object.values(r).reduce((a, b) => a + b, 0);
}

export function revenue(region: Region, ym: string): number {
  if (region === "Company") {
    return dataset.company[ym]?.["Netto-omzet"] ?? 0;
  }
  if (region === "Andijk") {
    return sumRecord(dataset.andijk[ym]);
  }
  // Winschoten — use actual reconciled Yuki data
  return sumRecord(dataset.winschoten?.[ym]);
}

export function collections(ym: string): number {
  return dataset.company[ym]?.["Collections"] ?? 0;
}

export function formatEUR(n: number): string {
  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(n);
  if (abs >= 1e6) return `${sign}€${(abs / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `${sign}€${(abs / 1e3).toFixed(0)}k`;
  return `${sign}€${abs.toFixed(0)}`;
}

export function monthLabel(ym: string): string {
  const [y, m] = ym.split("-");
  const names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${names[parseInt(m) - 1]} '${y.slice(2)}`;
}

// Seasonality factor: roofing — lower in winter (Dec-Feb), peak summer
const seasonality = [0.78, 0.82, 1.0, 1.08, 1.12, 1.15, 1.1, 0.7, 1.15, 1.18, 1.05, 0.85];

export function seasonalityFor(monthIdx: number): number {
  return seasonality[monthIdx];
}

// 13-week forecast based on trailing avg + seasonality + weather working-day factor
export interface WeeklyForecast {
  weekStart: string;
  weekIdx: number;
  baseRevenue: number;
  weatherAdj: number;
  forecastRevenue: number;
  collections: number;
  outflows: number;
  netCashFlow: number;
  cumulativeCash: number;
  workingDays: number;
  badWeatherDays: number;
  monthIdx: number;
  // Breakdown components — exposed so worked examples in the UI match the chart
  effectiveDays: number;
  seasonality: number;
  weekOfMonth: number;
  womFactor: number;
  jobTimingFactor: number; // deterministic ±12% pipeline / job-start timing variability
  trailingDailyRev: number;
  collectionsSource: number;
  collectionsSourceLabel: string;
  payroll: number;
  overhead: number;
  materialsSubs: number;
  taxRemit: number;
  isMonthEndWeek: boolean;
}

export function buildForecast(
  region: Region,
  startCash: number,
  weatherByDay: Map<string, { precip: number; wind: number; tmax?: number; tmin?: number; weatherCode?: number }>,
): WeeklyForecast[] {
  // Trailing 6-month avg revenue per working day (baseline run-rate)
  const sorted = [...months].sort();
  const last6 = sorted.slice(-6);
  const trailingRev = last6.reduce((a, m) => a + revenue(region, m), 0) / last6.length;
  const trailingDailyRev = trailingRev / 21;

  // Historical monthly revenue map — used for lagged collections in early weeks
  const histDailyByMonth = new Map<string, number>();
  sorted.forEach((m) => histDailyByMonth.set(m, revenue(region, m) / 21));

  const today = new Date();
  const start = new Date(today);
  start.setDate(start.getDate() - start.getDay() + 1); // Monday

  // Deterministic pseudo-random for backlog / pipeline lumpiness per week
  const rand = (seed: number) => {
    const x = Math.sin(seed * 9301 + 49297) * 233280;
    return x - Math.floor(x);
  };

  // ── Pass 1: forecast revenue per week (with intra-month + pipeline variance)
  const prelim = [] as Array<{
    wStart: Date;
    monthIdx: number;
    ym: string;
    workingDays: number;
    badDays: number;
    effectiveDays: number;
    forecastRevenue: number;
    baseRevenue: number;
    weatherAdj: number;
    seasonality: number;
    weekOfMonth: number;
    womFactor: number;
    jobTimingFactor: number;
    isMonthEndWeek: boolean;
  }>;

  for (let w = 0; w < 13; w++) {
    const wStart = new Date(start);
    wStart.setDate(wStart.getDate() + w * 7);
    const monthIdx = wStart.getMonth();
    const ym = `${wStart.getFullYear()}-${String(monthIdx + 1).padStart(2, "0")}`;
    const season = seasonalityFor(monthIdx);

    let workingDays = 0;
    let badDays = 0;
    for (let d = 0; d < 7; d++) {
      const day = new Date(wStart);
      day.setDate(day.getDate() + d);
      const dow = day.getDay();
      if (dow === 0 || dow === 6) continue;
      workingDays++;
      const key = day.toISOString().slice(0, 10);
      const wx = weatherByDay.get(key);
      if (wx && isAdverseDay(wx)) badDays++;
    }
    const effectiveDays = workingDays - badDays * 0.7;

    // Week-of-month pattern: roofing crews ramp into the month, peak mid, taper late
    const weekOfMonth = Math.ceil(wStart.getDate() / 7); // 1..5
    const womProfile = [0.92, 1.05, 1.08, 0.98, 0.85];
    const wom = womProfile[Math.min(weekOfMonth - 1, 4)];

    // Job-start timing factor ±12% — deterministic pipeline lumpiness
    const jobTiming = 0.88 + rand(w + 1) * 0.24;

    // Is this the last working-day week of the month (drives BTW / payroll-tax outflow)
    const nextWeek = new Date(wStart); nextWeek.setDate(nextWeek.getDate() + 7);
    const isMonthEndWeek = nextWeek.getMonth() !== monthIdx;

    const baseRevenue = trailingDailyRev * workingDays * season * wom * jobTiming;
    const forecastRevenue = trailingDailyRev * effectiveDays * season * wom * jobTiming;
    const weatherAdj = forecastRevenue - baseRevenue;

    prelim.push({ wStart, monthIdx, ym, workingDays, badDays, effectiveDays, forecastRevenue, baseRevenue, weatherAdj, seasonality: season, weekOfMonth, womFactor: wom, jobTimingFactor: jobTiming, isMonthEndWeek });
  }

  // ── Pass 2: cash mechanics
  const COLL_LAG_WEEKS = 6;
  const COLL_RATE = 0.92;

  const weeklyPayroll = (trailingRev * 0.22) / 4.33;
  const weeklyOverhead = (trailingRev * 0.06) / 4.33;

  const weeks: WeeklyForecast[] = [];
  let cumulative = startCash;

  for (let w = 0; w < 13; w++) {
    const p = prelim[w];

    let collectionsSource: number;
    let collectionsSourceLabel: string;
    const lagIdx = w - COLL_LAG_WEEKS;
    if (lagIdx >= 0) {
      collectionsSource = prelim[lagIdx].forecastRevenue;
      collectionsSourceLabel = `W${lagIdx + 1} forecast revenue`;
    } else {
      const past = new Date(p.wStart);
      past.setDate(past.getDate() - COLL_LAG_WEEKS * 7);
      const pYM = `${past.getFullYear()}-${String(past.getMonth() + 1).padStart(2, "0")}`;
      const pDaily = histDailyByMonth.get(pYM) ?? trailingDailyRev;
      collectionsSource = pDaily * 5 * (0.9 + rand(100 - w) * 0.2);
      collectionsSourceLabel = `${pYM} Yuki actuals (€${Math.round(pDaily).toLocaleString()}/day × 5)`;
    }
    const collections = collectionsSource * COLL_RATE;

    const materialsSubs = p.forecastRevenue * 0.38;
    const taxRemit = p.isMonthEndWeek
      ? (histDailyByMonth.get(p.ym) ?? trailingDailyRev) * 21 * 0.14
      : 0;
    const outflows = weeklyPayroll + weeklyOverhead + materialsSubs + taxRemit;

    const net = collections - outflows;
    cumulative += net;

    weeks.push({
      weekStart: p.wStart.toISOString().slice(0, 10),
      weekIdx: w + 1,
      baseRevenue: p.baseRevenue,
      weatherAdj: p.weatherAdj,
      forecastRevenue: p.forecastRevenue,
      collections,
      outflows,
      netCashFlow: net,
      cumulativeCash: cumulative,
      workingDays: p.workingDays,
      badWeatherDays: p.badDays,
      monthIdx: p.monthIdx,
      effectiveDays: p.effectiveDays,
      seasonality: p.seasonality,
      weekOfMonth: p.weekOfMonth,
      womFactor: p.womFactor,
      jobTimingFactor: p.jobTimingFactor,
      trailingDailyRev,
      collectionsSource,
      collectionsSourceLabel,
      payroll: weeklyPayroll,
      overhead: weeklyOverhead,
      materialsSubs,
      taxRemit,
      isMonthEndWeek: p.isMonthEndWeek,
    });
  }
  return weeks;
}

export function buildInsights(weeks: WeeklyForecast[], region: Region): Array<{
  severity: "info" | "warn" | "critical";
  title: string;
  detail: string;
}> {
  const out: Array<{ severity: "info" | "warn" | "critical"; title: string; detail: string }> = [];
  const totalBadDays = weeks.reduce((a, b) => a + b.badWeatherDays, 0);
  const totalWorking = weeks.reduce((a, b) => a + b.workingDays, 0);
  const weatherDrag = weeks.reduce((a, b) => a + b.weatherAdj, 0);

  if (totalBadDays > 8) {
    out.push({
      severity: "warn",
      title: "Weather drag on 13-week revenue",
      detail: `${totalBadDays} of ${totalWorking} working days flagged as adverse (wind ≥36 km/h, temp outside 0–29 °C, thunderstorm, fog, snow/freezing, or precip >25 mm) — estimated ${formatEUR(weatherDrag)} revenue impact for ${region}.`,
    });
  }
  const minCash = Math.min(...weeks.map((w) => w.cumulativeCash));
  if (minCash < 250_000) {
    out.push({
      severity: "critical",
      title: "Cash trough below €250k threshold",
      detail: `Projected cumulative cash dips to ${formatEUR(minCash)} — consider drawing on RCF or accelerating collections.`,
    });
  }
  const summerWeeks = weeks.filter((w) => w.monthIdx === 7);
  if (summerWeeks.length > 0) {
    out.push({
      severity: "info",
      title: "August seasonality (Dutch holiday)",
      detail: `Historical Aug factor 0.70× — schedule installs around weeks ${summerWeeks.map((w) => w.weekIdx).join(", ")}.`,
    });
  }
  const negativeWeeks = weeks.filter((w) => w.netCashFlow < 0);
  if (negativeWeeks.length >= 3) {
    out.push({
      severity: "warn",
      title: "Multiple negative cash-flow weeks",
      detail: `${negativeWeeks.length} of 13 weeks show net outflow. Largest: ${formatEUR(Math.min(...negativeWeeks.map((w) => w.netCashFlow)))} in week ${negativeWeeks.sort((a, b) => a.netCashFlow - b.netCashFlow)[0].weekIdx}.`,
    });
  }
  return out;
}
