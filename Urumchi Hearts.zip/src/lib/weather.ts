// Open-Meteo: free, no key. Andijk ~52.74,5.18 ; Winschoten ~53.14,7.03
export const REGION_COORDS = {
  Andijk: { lat: 52.74, lon: 5.18 },
  Winschoten: { lat: 53.14, lon: 7.03 },
  Company: { lat: 52.94, lon: 6.1 }, // midpoint
};

export interface DayWeather {
  date: string;
  precip: number;       // mm/day
  wind: number;         // km/h (max)
  tmax: number;         // °C
  tmin: number;         // °C
  weatherCode?: number; // WMO code
}

// ─── Workable-day rule ────────────────────────────────────────────────
// A day is WORKABLE when ALL of the following are true:
//   1. Wind < 10 m/s             (≈ 36 km/h)
//   2. 0 °C < temperature < 29 °C (tmin > 0, tmax < 29)
//   3. Visibility > 50 m         (proxy: not dense fog, codes 45/48)
//   4. No frost / freezing / flooding
//      (tmin > 5 covers frost; exclude snow/freezing-rain codes 66–77;
//       precip_sum < 25 mm guards against flooding)
//   5. No thunderstorm within 10 km (codes 95–99 excluded)
//   6. Wind force < Beaufort 6   (< 39 km/h — subsumed by rule 1)
// A day is ADVERSE when any rule is violated.
const WMO_THUNDER = new Set([95, 96, 97, 98, 99]);
const WMO_FOG = new Set([45, 48]);
const WMO_SNOW_FREEZE = new Set([66, 67, 71, 73, 75, 77, 85, 86]);

export function isAdverseDay(w: { precip: number; wind: number; tmax?: number; tmin?: number; weatherCode?: number }): boolean {
  // 1 & 6: wind speed (km/h). 10 m/s = 36 km/h
  if (w.wind >= 36) return true;
  // 2: temperature window
  if (w.tmax !== undefined && w.tmax >= 29) return true;
  if (w.tmin !== undefined && w.tmin <= 0) return true;
  // 4: flooding proxy
  if (w.precip > 25) return true;
  // 3, 4, 5: weather code categories
  if (w.weatherCode !== undefined) {
    if (WMO_THUNDER.has(w.weatherCode)) return true;
    if (WMO_FOG.has(w.weatherCode)) return true;
    if (WMO_SNOW_FREEZE.has(w.weatherCode)) return true;
  }
  return false;
}

export async function fetchWeather(
  region: "Andijk" | "Winschoten" | "Company",
  _startISO: string,
  _endISO: string,
): Promise<DayWeather[]> {
  const { lat, lon } = REGION_COORDS[region];
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=precipitation_sum,wind_speed_10m_max,temperature_2m_max,temperature_2m_min,weather_code&forecast_days=16&timezone=Europe%2FAmsterdam`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("weather fetch failed");
  const j = await res.json();
  const days = j.daily?.time ?? [];
  const live: DayWeather[] = days.map((d: string, i: number) => ({
    date: d,
    precip: j.daily.precipitation_sum[i] ?? 0,
    wind: j.daily.wind_speed_10m_max[i] ?? 0,
    tmax: j.daily.temperature_2m_max[i] ?? 0,
    tmin: j.daily.temperature_2m_min[i] ?? 0,
    weatherCode: j.daily.weather_code?.[i],
  }));
  // Climatology fallback for days beyond live forecast (Netherlands monthly avg)
  const clim = [
    [2.4, 32, 1, 6], [1.9, 30, 1, 7], [1.7, 31, 3, 10], [1.4, 29, 5, 14],
    [1.6, 27, 8, 18], [2.1, 25, 11, 21], [2.4, 25, 13, 23], [2.6, 25, 13, 23],
    [2.5, 27, 10, 19], [2.7, 30, 7, 15], [2.6, 32, 4, 10], [2.5, 33, 2, 7],
  ];
  const out = [...live];
  const lastDate = live.length ? new Date(live[live.length - 1].date) : new Date();
  for (let i = 1; i <= 91 - live.length; i++) {
    const d = new Date(lastDate); d.setDate(d.getDate() + i);
    const m = d.getMonth();
    const [pr, wn, tn, tx] = clim[m];
    const seed = d.getDate() * 31 + m;
    const wob = ((seed * 9301 + 49297) % 233280) / 233280;
    out.push({
      date: d.toISOString().slice(0, 10),
      precip: Math.max(0, pr * (0.4 + wob * 1.6)),
      wind: wn * (0.7 + wob * 0.7),
      tmax: tx + (wob - 0.5) * 4,
      tmin: tn + (wob - 0.5) * 3,
      weatherCode: 0,
    });
  }
  return out;
}

export async function fetchHistoricalWeather(
  region: "Andijk" | "Winschoten" | "Company",
  startISO: string,
  endISO: string,
): Promise<DayWeather[]> {
  const { lat, lon } = REGION_COORDS[region];
  const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lat}&longitude=${lon}&start_date=${startISO}&end_date=${endISO}&daily=precipitation_sum,wind_speed_10m_max,temperature_2m_max,temperature_2m_min,weather_code&timezone=Europe%2FAmsterdam`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("historical weather fetch failed");
  const j = await res.json();
  const days: string[] = j.daily?.time ?? [];
  return days.map((d, i) => ({
    date: d,
    precip: j.daily.precipitation_sum[i] ?? 0,
    wind: j.daily.wind_speed_10m_max[i] ?? 0,
    tmax: j.daily.temperature_2m_max[i] ?? 0,
    tmin: j.daily.temperature_2m_min[i] ?? 0,
    weatherCode: j.daily.weather_code?.[i],
  }));
}

// ─── Scenario weather (stress-test the cash forecast) ─────────────────
export type ScenarioMode = "live" | "preset" | "custom" | "synthetic";
export type PresetKey = "mild2024" | "wetAutumn2023" | "stormyWinter2024" | "heatwave2022" | "frozenFeb2021";

export const SCENARIO_PRESETS: Record<PresetKey, { label: string; start: string; description: string }> = {
  mild2024:         { label: "Mild baseline · Jun–Aug 2024",      start: "2024-06-03", description: "Calm summer — light reference case" },
  wetAutumn2023:    { label: "Wet autumn · Oct–Dec 2023",         start: "2023-10-02", description: "Storms Babet & Ciarán, heavy rain" },
  stormyWinter2024: { label: "Stormy winter · Jan–Mar 2024",      start: "2024-01-01", description: "Storms Henk, Isha, Jocelyn" },
  heatwave2022:    { label: "Heatwave · Jul–Sep 2022",            start: "2022-07-04", description: "Multiple >29 °C days, drought" },
  frozenFeb2021:   { label: "Frozen February · Feb–Apr 2021",     start: "2021-02-01", description: "Sub-zero week, snow, freezing rain" },
};

export interface Scenario {
  mode: ScenarioMode;
  presetKey?: PresetKey;
  customStart?: string;     // ISO date
  adverseDays?: number;     // stress-test: number of working days forced adverse over 13 weeks
}

export function scenarioLabel(s: Scenario): string {
  if (s.mode === "live") return "Live forecast (Open-Meteo)";
  if (s.mode === "preset" && s.presetKey) return SCENARIO_PRESETS[s.presetKey].label;
  if (s.mode === "custom" && s.customStart) return `Custom replay from ${s.customStart}`;
  if (s.mode === "synthetic") return `Stress test · ${s.adverseDays ?? 0} adverse days`;
  return "Live forecast";
}

function todayMonday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - d.getDay() + 1);
  return d;
}

function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function iso(d: Date): string {
  return d.toISOString().slice(0, 10);
}

// Remap a historical window onto today + 91 days (preserving precip/wind/temp/code)
function remapForward(historical: DayWeather[]): DayWeather[] {
  const start = todayMonday();
  return historical.slice(0, 91).map((d, i) => ({
    ...d,
    date: iso(addDays(start, i)),
  }));
}

// Force exactly N working days (Mon–Fri) in the window into adverse status,
// spread evenly across the 13-week horizon. Deterministic: same N → same days.
function applyAdverseDays(live: DayWeather[], n: number): DayWeather[] {
  const workingIdx: number[] = [];
  live.forEach((d, i) => {
    const dow = new Date(d.date).getDay();
    if (dow !== 0 && dow !== 6) workingIdx.push(i);
  });
  const total = workingIdx.length;
  const count = Math.max(0, Math.min(n, total));
  if (count === 0) return live;
  const picks = new Set<number>();
  for (let k = 0; k < count; k++) {
    picks.add(workingIdx[Math.floor((k + 0.5) * total / count)]);
  }
  return live.map((d, i) =>
    picks.has(i) ? { ...d, precip: Math.max(d.precip, 30) } : d,
  );
}


export async function fetchScenarioWeather(
  region: "Andijk" | "Winschoten" | "Company",
  scenario: Scenario,
): Promise<DayWeather[]> {
  const today = new Date();
  const endProj = addDays(today, 91);

  if (scenario.mode === "live") {
    return fetchWeather(region, iso(today), iso(endProj));
  }

  if (scenario.mode === "preset" && scenario.presetKey) {
    const start = SCENARIO_PRESETS[scenario.presetKey].start;
    const end = iso(addDays(new Date(start), 95));
    const hist = await fetchHistoricalWeather(region, start, end);
    return remapForward(hist);
  }

  if (scenario.mode === "custom" && scenario.customStart) {
    const end = iso(addDays(new Date(scenario.customStart), 95));
    const hist = await fetchHistoricalWeather(region, scenario.customStart, end);
    return remapForward(hist);
  }

  if (scenario.mode === "synthetic") {
    const live = await fetchWeather(region, iso(today), iso(endProj));
    return applyAdverseDays(live, scenario.adverseDays ?? 0);
  }

  return fetchWeather(region, iso(today), iso(endProj));
}

