import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const RiskWeekSchema = z.object({
  weekIdx: z.number(),
  weekStart: z.string(),
  netCashFlow: z.number(),
  cumulativeCash: z.number(),
  workingDays: z.number(),
  badWeatherDays: z.number(),
});

const FactsSchema = z.object({
  region: z.string(),
  scenarioLabel: z.string(),
  trough: z.object({
    amount: z.number(),
    weekIdx: z.number(),
    weekStart: z.string(),
    headroom: z.number(),
    belowCovenant: z.boolean(),
  }),
  topRiskWeek: RiskWeekSchema,
  weatherDrag: z.object({
    revenueImpact: z.number(),
    adverseDays: z.number(),
    workingDays: z.number(),
  }),
  recommendedAction: z.string(),
  negativeWeekCount: z.number(),
  endCash: z.number(),
  startCash: z.number(),
  riskWeeks: z.array(RiskWeekSchema),
});

const InputSchema = z.object({ facts: FactsSchema });

const SYSTEM_PROMPT = `You are a CFO advisor briefing a busy roofing-company CFO.
Write a crisp 4-6 sentence executive summary in plain English (no markdown headings, no bullet lists, no bold).
Lead with the cash trough number and the week it hits. Then quantify the weather drag in € and adverse days.
Then call out the worst net cash-flow week. End with one concrete recommended action.
Use € amounts rounded as given. Do not invent numbers beyond what is provided.`;

export const generateCfoBriefing = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      return { narrative: null as string | null, error: "Lovable AI is not configured (missing LOVABLE_API_KEY)." };
    }

    const factsBlock = [
      `Region: ${data.facts.region}`,
      `Scenario: ${data.facts.scenarioLabel}`,
      `Start cash €${Math.round(data.facts.startCash).toLocaleString()}; End cash €${Math.round(data.facts.endCash).toLocaleString()}`,
      `Cash trough €${Math.round(data.facts.trough.amount).toLocaleString()} in W${data.facts.trough.weekIdx} (${data.facts.trough.weekStart}); headroom vs €250k covenant €${Math.round(data.facts.trough.headroom).toLocaleString()}${data.facts.trough.belowCovenant ? " — BELOW FLOOR" : ""}`,
      `Top risk week: W${data.facts.topRiskWeek.weekIdx} net €${Math.round(data.facts.topRiskWeek.netCashFlow).toLocaleString()}, ${data.facts.topRiskWeek.badWeatherDays}/${data.facts.topRiskWeek.workingDays} adverse days`,
      `Weather drag: €${Math.round(data.facts.weatherDrag.revenueImpact).toLocaleString()} on revenue, ${data.facts.weatherDrag.adverseDays}/${data.facts.weatherDrag.workingDays} adverse working days`,
      `Net-negative weeks: ${data.facts.negativeWeekCount} of 13`,
      `Heuristic action: ${data.facts.recommendedAction}`,
    ].join("\n");

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Lovable-API-Key": key,
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            { role: "user", content: `Here are the forecast facts:\n\n${factsBlock}\n\nWrite the briefing now.` },
          ],
        }),
      });

      if (!res.ok) {
        const body = await res.text().catch(() => "");
        if (res.status === 429) {
          return { narrative: null, error: "AI rate limit hit — please try again in a moment." };
        }
        if (res.status === 402) {
          return { narrative: null, error: "Lovable AI credits are exhausted. Add credits in Workspace Settings → Usage." };
        }
        return { narrative: null, error: `AI gateway error (${res.status}): ${body.slice(0, 200)}` };
      }

      const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
      const narrative = json.choices?.[0]?.message?.content?.trim() ?? "";
      if (!narrative) {
        return { narrative: null, error: "AI returned an empty response." };
      }
      return { narrative, error: null as string | null };
    } catch (err) {
      console.error("generateCfoBriefing failed:", err);
      return { narrative: null, error: "Could not reach the AI service." };
    }
  });
