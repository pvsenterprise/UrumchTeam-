import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

// ---------- CSV parser (Yuki ledger format) ----------
// Expected headers (case-insensitive, order-tolerant):
// Rekening, Periode, Datum, Boeknummer, Trek, Debet, Credit, Boekingstekst, Dagboek, BTW, BTW-srt

function splitCsvLine(line: string, sep: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQ && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else inQ = !inQ;
    } else if (c === sep && !inQ) {
      out.push(cur);
      cur = "";
    } else cur += c;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

function detectSep(headerLine: string): string {
  const semi = (headerLine.match(/;/g) || []).length;
  const com = (headerLine.match(/,/g) || []).length;
  return semi > com ? ";" : ",";
}

function parseNum(v: string | undefined): number | null {
  if (!v) return null;
  let s = v.trim();
  if (!s) return null;
  // Strip currency symbols and spaces
  s = s.replace(/[€$\s]/g, "");
  // Detect decimal separator: whichever of "," or "." appears LAST is the decimal.
  const lastComma = s.lastIndexOf(",");
  const lastDot = s.lastIndexOf(".");
  if (lastComma >= 0 && lastDot >= 0) {
    if (lastComma > lastDot) {
      // Dutch: 1.234,56 → 1234.56
      s = s.replace(/\./g, "").replace(",", ".");
    } else {
      // English: 1,234.56 → 1234.56
      s = s.replace(/,/g, "");
    }
  } else if (lastComma >= 0) {
    // Only comma → decimal separator
    s = s.replace(/,/g, ".");
  }
  // Only dot, or no separator → already JS-parseable.
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function parseDate(v: string | undefined): string | null {
  if (!v) return null;
  const s = v.trim();
  // dd-mm-yyyy or dd/mm/yyyy
  const m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
  if (m) {
    const [, d, mo, y] = m;
    return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  // yyyy-mm-dd (optionally with time)
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  // Require an explicit date-shaped string before trusting Date parsing.
  if (/\d{4}/.test(s) && /[-/]/.test(s)) {
    const d = new Date(s);
    if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  }
  return null;
}

export type ParsedLedgerRow = {
  rekening: number | null;
  periode: string | null;
  boekdatum: string | null;
  boeknummer: string | null;
  trek: string | null;
  debet: number | null;
  credit: number | null;
  boekingstekst: string | null;
  dagboek: string | null;
  btw: number | null;
  btw_srt: string | null;
};

export function parseYukiLedgerCsv(csv: string): { rows: ParsedLedgerRow[]; failed: number } {
  const text = csv.replace(/^\uFEFF/, "");
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return { rows: [], failed: 0 };

  // Detect separator from the densest line in the first 30 (criteria rows are sparse).
  const sample = lines.slice(0, Math.min(30, lines.length));
  const sep = detectSep(sample.reduce((a, b) => (b.length > a.length ? b : a), ""));

  // Find the table header row. Two known Yuki layouts:
  //  A) GL ledger: contains "rekening" + ("debet"|"credit")
  //  B) Per-account "FinTransactions": contains "debet" + "credit" but no "rekening"
  //     (columns: Nr., Per., Datum, Bkst.nr., Dagboek, Debet, Credit)
  let headerIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    const low = lines[i].toLowerCase();
    if (/(^|[;,\s"])rekening([;,\s"]|$)/.test(low) && /debet/.test(low) && /credit/.test(low)) {
      headerIdx = i;
      break;
    }
  }
  let layout: "gl" | "fin" = "gl";
  if (headerIdx < 0) {
    for (let i = 0; i < lines.length; i++) {
      const low = lines[i].toLowerCase();
      if (/debet/.test(low) && /credit/.test(low) && /(datum|per\.)/.test(low)) {
        headerIdx = i;
        layout = "fin";
        break;
      }
    }
  }
  if (headerIdx < 0) return { rows: [], failed: lines.length };

  const headers = splitCsvLine(lines[headerIdx], sep).map((h) => h.toLowerCase().replace(/\s+/g, " ").trim());
  const findIdx = (...names: string[]) =>
    headers.findIndex((h) => names.some((n) => h === n.toLowerCase()));

  const col = {
    rekening: findIdx("rekening"),
    periode: findIdx("periode", "per.", "per"),
    datum: findIdx("datum", "boekdatum"),
    boeknummer: findIdx("boeknummer", "bkst.nr.", "bkst nr", "bkstnr", "nr.", "nr"),
    trek: findIdx("trek"),
    debet: findIdx("debet"),
    credit: findIdx("credit"),
    boekingstekst: findIdx("boekingstekst", "omschrijving"),
    dagboek: findIdx("dagboek"),
    btw: findIdx("btw"),
    btwsrt: findIdx("btw-srt", "btw srt", "btwsrt"),
  };

  // For FinTransactions: extract Grootboekrekening + Boekjaar from preamble.
  let preambleRekening: number | null = null;
  let preambleYear: number | null = null;
  if (layout === "fin") {
    for (let i = 0; i < headerIdx; i++) {
      const cells = splitCsvLine(lines[i], sep);
      for (let j = 0; j < cells.length; j++) {
        const c = cells[j].toLowerCase();
        if (preambleRekening === null && /grootboekrekening/.test(c)) {
          // value is in this cell after a colon, or in the next non-empty cell
          const inline = cells[j].match(/(\d{3,6})/);
          if (inline) preambleRekening = Number(inline[1]);
          else {
            for (let k = j + 1; k < cells.length; k++) {
              const m = cells[k].match(/(\d{3,6})/);
              if (m) { preambleRekening = Number(m[1]); break; }
            }
          }
        }
        if (preambleYear === null && /boekjaar/.test(c)) {
          const inline = cells[j].match(/(20\d{2})/);
          if (inline) preambleYear = Number(inline[1]);
          else {
            for (let k = j + 1; k < cells.length; k++) {
              const m = cells[k].match(/(20\d{2})/);
              if (m) { preambleYear = Number(m[1]); break; }
            }
          }
        }
      }
    }
  }

  const rows: ParsedLedgerRow[] = [];
  let failed = 0;
  for (let i = headerIdx + 1; i < lines.length; i++) {
    const parts = splitCsvLine(lines[i], sep);
    if (parts.length < 3) {
      failed++;
      continue;
    }
    const get = (k: number) => (k >= 0 && k < parts.length ? parts[k] : undefined);
    const boeknummerRaw = (get(col.boeknummer) || "").trim();
    // Skip summary/balance rows that Yuki appends (Beginsaldo, Eindsaldo, Totaal, Saldo, etc.)
    if (/^(begin|eind|tussen)?saldo|^totaal/i.test(boeknummerRaw)) {
      continue;
    }
    const rekeningCell = parseNum(get(col.rekening));
    const rekening = rekeningCell !== null ? Math.trunc(rekeningCell) : preambleRekening;
    const debet = parseNum(get(col.debet));
    const credit = parseNum(get(col.credit));
    if (rekening === null && debet === null && credit === null) {
      failed++;
      continue;
    }
    const boekdatum = parseDate(get(col.datum));
    // Periode: explicit cell, else derive from boekjaar + Per. month (FinTransactions), else boekdatum month.
    let periode = parseDate(get(col.periode));
    if (!periode) {
      const perRaw = get(col.periode);
      const monthNum = perRaw ? Number(perRaw.replace(",", ".").trim()) : NaN;
      if (preambleYear && Number.isFinite(monthNum) && monthNum >= 1 && monthNum <= 12) {
        periode = `${preambleYear}-${String(Math.trunc(monthNum)).padStart(2, "0")}-01`;
      } else if (boekdatum) {
        periode = `${boekdatum.slice(0, 7)}-01`;
      }
    }
    rows.push({
      rekening,
      periode,
      boekdatum,
      boeknummer: get(col.boeknummer) || null,
      trek: get(col.trek) || null,
      debet,
      credit,
      boekingstekst: get(col.boekingstekst) || null,
      dagboek: get(col.dagboek) || null,
      btw: parseNum(get(col.btw)),
      btw_srt: get(col.btwsrt) || null,
    });
  }
  return { rows, failed };
}

// ---------- Server functions ----------

const connectSchema = z.object({
  administrationId: z.string().min(1).max(128),
  administrationName: z.string().max(256).optional(),
  accessKey: z.string().min(8).max(128),
});

export const connectYuki = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => connectSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // simulate OAuth token exchange
    const last8 = data.accessKey.slice(-8);
    const { data: row, error } = await supabaseAdmin
      .from("yuki_connections")
      .insert({
        administration_id: data.administrationId,
        administration_name: data.administrationName ?? null,
        access_key_last8: last8,
        status: "active",
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { connection: row };
  });

export const disconnectYuki = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("yuki_connections")
      .update({ status: "disconnected" })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const ingestSchema = z.object({
  fileName: z.string().min(1).max(255),
  csv: z.string().min(1).max(20_000_000),
  connectionId: z.string().uuid().optional(),
  source: z.enum(["yuki_oauth", "manual_upload"]).default("yuki_oauth"),
});

export const ingestLedgerCsv = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => ingestSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: run, error: runErr } = await supabaseAdmin
      .from("yuki_sync_runs")
      .insert({
        connection_id: data.connectionId ?? null,
        file_name: data.fileName,
        source: data.source,
        status: "processing",
      })
      .select()
      .single();
    if (runErr || !run) throw new Error(runErr?.message ?? "Failed to create sync run");

    try {
      const { rows, failed } = parseYukiLedgerCsv(data.csv);
      if (rows.length === 0) {
        throw new Error(
          `Could not parse any rows from ${data.fileName}. Expected Yuki GL ledger (columns: Rekening, Periode, Datum, Debet, Credit, …) or Yuki FinTransactions per-account report (columns: Nr., Per., Datum, Bkst.nr., Dagboek, Debet, Credit with Grootboekrekening in the report criteria block). Lines scanned: ${failed}.`,
        );
      }

      let totalDebet = 0;
      let totalCredit = 0;
      let minPeriod: string | null = null;
      let maxPeriod: string | null = null;
      for (const r of rows) {
        if (r.debet) totalDebet += r.debet;
        if (r.credit) totalCredit += r.credit;
        const p = r.periode ?? r.boekdatum;
        if (p) {
          if (!minPeriod || p < minPeriod) minPeriod = p;
          if (!maxPeriod || p > maxPeriod) maxPeriod = p;
        }
      }

      // batch insert entries
      const batchSize = 500;
      for (let i = 0; i < rows.length; i += batchSize) {
        const slice = rows.slice(i, i + batchSize).map((r) => ({ ...r, sync_run_id: run.id }));
        const { error: insErr } = await supabaseAdmin.from("yuki_ledger_entries").insert(slice);
        if (insErr) throw new Error(insErr.message);
      }

      await supabaseAdmin
        .from("yuki_sync_runs")
        .update({
          status: "completed",
          rows_received: rows.length + failed,
          rows_processed: rows.length,
          rows_failed: failed,
          total_debet: Number(totalDebet.toFixed(2)),
          total_credit: Number(totalCredit.toFixed(2)),
          period_start: minPeriod,
          period_end: maxPeriod,
          finished_at: new Date().toISOString(),
        })
        .eq("id", run.id);

      if (data.connectionId) {
        await supabaseAdmin
          .from("yuki_connections")
          .update({ last_sync_at: new Date().toISOString() })
          .eq("id", data.connectionId);
      }

      return {
        runId: run.id,
        status: "completed" as const,
        rowsProcessed: rows.length,
        rowsFailed: failed,
        totalDebet,
        totalCredit,
        periodStart: minPeriod,
        periodEnd: maxPeriod,
      };
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      await supabaseAdmin
        .from("yuki_sync_runs")
        .update({
          status: "failed",
          error_message: msg.slice(0, 500),
          finished_at: new Date().toISOString(),
        })
        .eq("id", run.id);
      return { runId: run.id, status: "failed" as const, error: msg };
    }
  });

export type YukiMetrics = {
  totalDebet: number;
  totalCredit: number;
  netRevenue: number;
  monthly: { ym: string; debet: number; credit: number; net: number }[];
  topAccounts: { rekening: number; credit: number; debet: number }[];
  periodStart: string | null;
  periodEnd: string | null;
};

export const getYukiMetrics = createServerFn({ method: "GET" }).handler(async (): Promise<YukiMetrics> => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("yuki_ledger_entries")
    .select("rekening, periode, debet, credit")
    .limit(50000);
  if (error) throw new Error(error.message);

  let totalDebet = 0;
  let totalCredit = 0;
  const byMonth = new Map<string, { d: number; c: number }>();
  const byAcct = new Map<number, { d: number; c: number }>();
  let pStart: string | null = null;
  let pEnd: string | null = null;

  for (const r of data ?? []) {
    const d = Number(r.debet ?? 0);
    const c = Number(r.credit ?? 0);
    totalDebet += d;
    totalCredit += c;
    const ym = r.periode ? String(r.periode).slice(0, 7) : null;
    if (ym) {
      const m = byMonth.get(ym) ?? { d: 0, c: 0 };
      m.d += d;
      m.c += c;
      byMonth.set(ym, m);
      if (!pStart || ym < pStart) pStart = ym;
      if (!pEnd || ym > pEnd) pEnd = ym;
    }
    if (r.rekening != null) {
      const a = byAcct.get(r.rekening) ?? { d: 0, c: 0 };
      a.d += d;
      a.c += c;
      byAcct.set(r.rekening, a);
    }
  }

  const monthly = [...byMonth.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([ym, v]) => ({ ym, debet: v.d, credit: v.c, net: v.c - v.d }));

  const topAccounts = [...byAcct.entries()]
    .map(([rekening, v]) => ({ rekening, credit: v.c, debet: v.d }))
    .sort((a, b) => b.credit - a.credit)
    .slice(0, 8);

  return {
    totalDebet,
    totalCredit,
    netRevenue: totalCredit - totalDebet,
    monthly,
    topAccounts,
    periodStart: pStart,
    periodEnd: pEnd,
  };
});
