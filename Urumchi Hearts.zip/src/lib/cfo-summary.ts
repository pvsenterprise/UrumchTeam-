import type { WeeklyForecast } from "@/lib/altis-data";
import { formatEUR } from "@/lib/altis-data";

const COVENANT_THRESHOLD = 250_000;

export interface RiskWeek {
  weekIdx: number;
  weekStart: string;
  netCashFlow: number;
  cumulativeCash: number;
  workingDays: number;
  badWeatherDays: number;
}

export interface SummaryFacts {
  region: string;
  scenarioLabel: string;
  trough: {
    amount: number;
    weekIdx: number;
    weekStart: string;
    headroom: number; // vs €250k covenant floor
    belowCovenant: boolean;
  };
  topRiskWeek: RiskWeek;
  weatherDrag: {
    revenueImpact: number; // negative number
    adverseDays: number;
    workingDays: number;
  };
  recommendedAction: string;
  negativeWeekCount: number;
  endCash: number;
  startCash: number;
  riskWeeks: RiskWeek[]; // top 3 by most-negative net
}

export function computeSummaryFacts(
  weeks: WeeklyForecast[],
  region: string,
  scenarioLabel: string,
  startCash: number,
): SummaryFacts {
  const troughWeek = weeks.reduce((a, b) => (b.cumulativeCash < a.cumulativeCash ? b : a), weeks[0]);
  const topRisk = weeks.reduce((a, b) => (b.netCashFlow < a.netCashFlow ? b : a), weeks[0]);
  const weatherImpact = weeks.reduce((s, w) => s + w.weatherAdj, 0);
  const adverseDays = weeks.reduce((s, w) => s + w.badWeatherDays, 0);
  const workingDays = weeks.reduce((s, w) => s + w.workingDays, 0);
  const negatives = weeks.filter((w) => w.netCashFlow < 0);

  const belowCovenant = troughWeek.cumulativeCash < COVENANT_THRESHOLD;
  const recommendedAction = belowCovenant
    ? `Draw on RCF before W${troughWeek.weekIdx} to defend the €250k covenant floor.`
    : negatives.length >= 3
      ? `Accelerate collections on top Yuki AR — ${negatives.length} of 13 weeks net-negative.`
      : `Hold course; tighten payables timing around W${topRisk.weekIdx} if needed.`;

  const toRiskWeek = (w: WeeklyForecast): RiskWeek => ({
    weekIdx: w.weekIdx,
    weekStart: w.weekStart,
    netCashFlow: w.netCashFlow,
    cumulativeCash: w.cumulativeCash,
    workingDays: w.workingDays,
    badWeatherDays: w.badWeatherDays,
  });

  const riskWeeks = [...weeks]
    .sort((a, b) => a.netCashFlow - b.netCashFlow)
    .slice(0, 3)
    .map(toRiskWeek);

  return {
    region,
    scenarioLabel,
    trough: {
      amount: troughWeek.cumulativeCash,
      weekIdx: troughWeek.weekIdx,
      weekStart: troughWeek.weekStart,
      headroom: troughWeek.cumulativeCash - COVENANT_THRESHOLD,
      belowCovenant,
    },
    topRiskWeek: toRiskWeek(topRisk),
    weatherDrag: {
      revenueImpact: weatherImpact,
      adverseDays,
      workingDays,
    },
    recommendedAction,
    negativeWeekCount: negatives.length,
    endCash: weeks[weeks.length - 1]?.cumulativeCash ?? startCash,
    startCash,
    riskWeeks,
  };
}

export function factsToPromptBlock(f: SummaryFacts): string {
  return [
    `Region: ${f.region}`,
    `Scenario: ${f.scenarioLabel}`,
    `Start cash: ${formatEUR(f.startCash)}; End cash (W13): ${formatEUR(f.endCash)}`,
    `Cash trough: ${formatEUR(f.trough.amount)} in week ${f.trough.weekIdx} (${f.trough.weekStart}); headroom vs €250k covenant: ${formatEUR(f.trough.headroom)}${f.trough.belowCovenant ? " (BELOW FLOOR)" : ""}`,
    `Top risk week: W${f.topRiskWeek.weekIdx} net ${formatEUR(f.topRiskWeek.netCashFlow)}, ${f.topRiskWeek.badWeatherDays}/${f.topRiskWeek.workingDays} adverse days`,
    `Weather drag over 13 weeks: ${formatEUR(f.weatherDrag.revenueImpact)} on revenue, ${f.weatherDrag.adverseDays}/${f.weatherDrag.workingDays} adverse working days`,
    `Net-negative weeks: ${f.negativeWeekCount} of 13`,
    `Suggested action (heuristic): ${f.recommendedAction}`,
  ].join("\n");
}
