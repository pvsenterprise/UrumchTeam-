export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      yuki_connections: {
        Row: {
          access_key_last8: string
          administration_id: string
          administration_name: string | null
          authorized_at: string
          created_at: string
          id: string
          last_sync_at: string | null
          status: string
        }
        Insert: {
          access_key_last8: string
          administration_id: string
          administration_name?: string | null
          authorized_at?: string
          created_at?: string
          id?: string
          last_sync_at?: string | null
          status?: string
        }
        Update: {
          access_key_last8?: string
          administration_id?: string
          administration_name?: string | null
          authorized_at?: string
          created_at?: string
          id?: string
          last_sync_at?: string | null
          status?: string
        }
        Relationships: []
      }
      yuki_ledger_entries: {
        Row: {
          boekdatum: string | null
          boekingstekst: string | null
          boeknummer: string | null
          btw: number | null
          btw_srt: string | null
          created_at: string
          credit: number | null
          dagboek: string | null
          debet: number | null
          id: number
          periode: string | null
          rekening: number | null
          sync_run_id: string
          trek: string | null
        }
        Insert: {
          boekdatum?: string | null
          boekingstekst?: string | null
          boeknummer?: string | null
          btw?: number | null
          btw_srt?: string | null
          created_at?: string
          credit?: number | null
          dagboek?: string | null
          debet?: number | null
          id?: number
          periode?: string | null
          rekening?: number | null
          sync_run_id: string
          trek?: string | null
        }
        Update: {
          boekdatum?: string | null
          boekingstekst?: string | null
          boeknummer?: string | null
          btw?: number | null
          btw_srt?: string | null
          created_at?: string
          credit?: number | null
          dagboek?: string | null
          debet?: number | null
          id?: number
          periode?: string | null
          rekening?: number | null
          sync_run_id?: string
          trek?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "yuki_ledger_entries_sync_run_id_fkey"
            columns: ["sync_run_id"]
            isOneToOne: false
            referencedRelation: "yuki_sync_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      yuki_sync_runs: {
        Row: {
          connection_id: string | null
          error_message: string | null
          file_name: string
          finished_at: string | null
          id: string
          period_end: string | null
          period_start: string | null
          rows_failed: number
          rows_processed: number
          rows_received: number
          source: string
          started_at: string
          status: string
          total_credit: number
          total_debet: number
        }
        Insert: {
          connection_id?: string | null
          error_message?: string | null
          file_name: string
          finished_at?: string | null
          id?: string
          period_end?: string | null
          period_start?: string | null
          rows_failed?: number
          rows_processed?: number
          rows_received?: number
          source?: string
          started_at?: string
          status?: string
          total_credit?: number
          total_debet?: number
        }
        Update: {
          connection_id?: string | null
          error_message?: string | null
          file_name?: string
          finished_at?: string | null
          id?: string
          period_end?: string | null
          period_start?: string | null
          rows_failed?: number
          rows_processed?: number
          rows_received?: number
          source?: string
          started_at?: string
          status?: string
          total_credit?: number
          total_debet?: number
        }
        Relationships: [
          {
            foreignKeyName: "yuki_sync_runs_connection_id_fkey"
            columns: ["connection_id"]
            isOneToOne: false
            referencedRelation: "yuki_connections"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
