import { useState, useCallback, useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Building2,
  CheckCircle2,
  ExternalLink,
  Loader2,
  Plug,
  ShieldCheck,
  Upload,
  RefreshCw,
  FileText,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { connectYuki, disconnectYuki, ingestLedgerCsv } from "@/lib/yuki.functions";

export const Route = createFileRoute("/connect-yuki")({
  head: () => ({
    meta: [
      { title: "Connect Yuki — Altis Treasury" },
      { name: "description", content: "Authorize Yuki, sync ledger CSV files, and review processing history." },
    ],
  }),
  component: ConnectYukiPage,
});

type Connection = {
  id: string;
  administration_id: string;
  administration_name: string | null;
  access_key_last8: string;
  status: string;
  authorized_at: string;
  last_sync_at: string | null;
};

type SyncRun = {
  id: string;
  file_name: string;
  source: string;
  status: string;
  rows_received: number;
  rows_processed: number;
  rows_failed: number;
  total_debet: number | string;
  total_credit: number | string;
  period_start: string | null;
  period_end: string | null;
  error_message: string | null;
  started_at: string;
  finished_at: string | null;
};

function ConnectYukiPage() {
  const qc = useQueryClient();
  const connectFn = useServerFn(connectYuki);
  const disconnectFn = useServerFn(disconnectYuki);
  const ingestFn = useServerFn(ingestLedgerCsv);

  const connQuery = useQuery({
    queryKey: ["yuki-connections"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("yuki_connections")
        .select("*")
        .eq("status", "active")
        .order("authorized_at", { ascending: false })
        .limit(1);
      if (error) throw error;
      return (data?.[0] as Connection | undefined) ?? null;
    },
  });

  const historyQuery = useQuery({
    queryKey: ["yuki-sync-history"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("yuki_sync_runs")
        .select("*")
        .order("started_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return (data ?? []) as SyncRun[];
    },
    refetchInterval: 5000,
  });

  const connection = connQuery.data;

  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Integrations</div>
          <h1 className="font-serif text-3xl font-semibold">Yuki Connection</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            OAuth-authorize a Yuki administration, pull ledger CSVs, and audit every processed file.
          </p>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ConnectionCard
          connection={connection}
          loading={connQuery.isLoading}
          onConnect={async (payload) => {
            await connectFn({ data: payload });
            await qc.invalidateQueries({ queryKey: ["yuki-connections"] });
            toast.success("Yuki authorized");
          }}
          onDisconnect={async () => {
            if (!connection) return;
            await disconnectFn({ data: { id: connection.id } });
            await qc.invalidateQueries({ queryKey: ["yuki-connections"] });
            toast.message("Yuki disconnected");
          }}
        />
        <SyncCard
          connection={connection}
          onIngest={async (fileName, csv) => {
            const res = await ingestFn({
              data: {
                fileName,
                csv,
                connectionId: connection?.id,
                source: connection ? "yuki_oauth" : "manual_upload",
              },
            });
            await qc.invalidateQueries({ queryKey: ["yuki-sync-history"] });
            await qc.invalidateQueries({ queryKey: ["yuki-connections"] });
            return res;
          }}
        />
      </div>

      <SyncHistory runs={historyQuery.data ?? []} loading={historyQuery.isLoading} />
    </div>
  );
}

function ConnectionCard({
  connection,
  loading,
  onConnect,
  onDisconnect,
}: {
  connection: Connection | null | undefined;
  loading: boolean;
  onConnect: (p: { administrationId: string; administrationName?: string; accessKey: string }) => Promise<void>;
  onDisconnect: () => Promise<void>;
}) {
  const [adminId, setAdminId] = useState("");
  const [adminName, setAdminName] = useState("");
  const [accessKey, setAccessKey] = useState("");
  const [busy, setBusy] = useState(false);

  const handleConnect = async () => {
    if (!adminId.trim() || !accessKey.trim()) {
      toast.error("Administration ID and AccessKey are required");
      return;
    }
    setBusy(true);
    try {
      await onConnect({
        administrationId: adminId.trim(),
        administrationName: adminName.trim() || undefined,
        accessKey: accessKey.trim(),
      });
      setAdminId("");
      setAdminName("");
      setAccessKey("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Connection failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-lg border border-border bg-card p-6">
      <h2 className="flex items-center gap-2 font-serif text-xl">
        <Building2 className="h-5 w-5 text-primary" />
        Authorization
      </h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Yuki Web Services token exchange (AccessKey GUID per administration).
      </p>

      {loading ? (
        <div className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : connection ? (
        <div className="mt-6 space-y-3 rounded-md border border-emerald-500/30 bg-emerald-500/5 p-4 text-sm">
          <div className="flex items-center gap-2 text-emerald-400">
            <CheckCircle2 className="h-4 w-4" />
            Connected to Yuki
          </div>
          <Row label="Administration" value={connection.administration_name ?? connection.administration_id} />
          <Row label="Administration ID" value={<span className="font-mono text-xs">{connection.administration_id}</span>} />
          <Row label="AccessKey" value={<span className="font-mono text-xs">••••-{connection.access_key_last8}</span>} />
          <Row label="Authorized" value={new Date(connection.authorized_at).toLocaleString()} />
          <Row
            label="Last sync"
            value={connection.last_sync_at ? new Date(connection.last_sync_at).toLocaleString() : "—"}
          />
          <div className="flex items-center gap-2 border-t border-border pt-3 text-xs text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            Token stored server-side. Only the last 8 characters of the AccessKey are surfaced to the client.
          </div>
          <Button variant="ghost" size="sm" onClick={onDisconnect} className="text-destructive">
            Disconnect
          </Button>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="admin-id">Administration ID</Label>
            <Input id="admin-id" placeholder="e.g. Altis-Groep-BV" value={adminId} onChange={(e) => setAdminId(e.target.value)} className="font-mono text-xs" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="admin-name">Administration name (optional)</Label>
            <Input id="admin-name" placeholder="Altis Groep B.V." value={adminName} onChange={(e) => setAdminName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ak">AccessKey</Label>
            <Input id="ak" placeholder="8f2c5b3a-4d1e-4a7b-9c6e-1f2a3b4c5d6e" value={accessKey} onChange={(e) => setAccessKey(e.target.value)} className="font-mono text-xs" />
            <p className="text-xs text-muted-foreground">
              In Yuki: Settings → Web Services → AccessKey
            </p>
          </div>
          <div className="flex items-center justify-between pt-2">
            <a href="https://www.yuki.nl/api" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
              Yuki Web Services docs <ExternalLink className="h-3 w-3" />
            </a>
            <Button onClick={handleConnect} disabled={busy}>
              {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Authorizing…</> : <><Plug className="h-4 w-4" /> Authorize</>}
            </Button>
          </div>
        </div>
      )}
    </section>
  );
}

function SyncCard({
  connection,
  onIngest,
}: {
  connection: Connection | null | undefined;
  onIngest: (fileName: string, csv: string) => Promise<{ status: string; rowsProcessed?: number; rowsFailed?: number; error?: string }>;
}) {
  const [busy, setBusy] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const handleFiles = useCallback(
    async (files: FileList | File[]) => {
      const arr = Array.from(files);
      if (arr.length === 0) return;
      setBusy(true);
      for (const f of arr) {
        if (!/\.csv$/i.test(f.name)) {
          toast.error(`${f.name}: only .csv files are accepted`);
          continue;
        }
        try {
          const csv = await f.text();
          const res = await onIngest(f.name, csv);
          if (res.status === "completed") {
            toast.success(`${f.name} processed`, {
              description: `${res.rowsProcessed ?? 0} rows · ${res.rowsFailed ?? 0} skipped`,
            });
          } else {
            toast.error(`${f.name} failed`, { description: res.error });
          }
        } catch (e) {
          toast.error(`${f.name}: ${e instanceof Error ? e.message : "upload failed"}`);
        }
      }
      setBusy(false);
    },
    [onIngest],
  );

  const handlePullFromYuki = async () => {
    toast.info("Pull from Yuki", {
      description:
        "Live SOAP pull is not active in this demo. Drop the CSV exported from Yuki Web Services here — it goes through the same parser and history pipeline.",
    });
  };

  return (
    <section className="rounded-lg border border-border bg-card p-6">
      <h2 className="flex items-center gap-2 font-serif text-xl">
        <RefreshCw className="h-5 w-5 text-primary" />
        Sync ledger
      </h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Pull from Yuki, or drop a ledger CSV. Files are parsed, persisted, and rolled up into the CFO dashboard metrics.
      </p>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (e.dataTransfer.files) handleFiles(e.dataTransfer.files);
        }}
        className={`mt-4 rounded-md border-2 border-dashed p-6 text-center text-sm transition-colors ${
          dragOver ? "border-primary bg-primary/5" : "border-border bg-muted/20"
        }`}
      >
        <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
        <div className="mt-2">Drop Yuki ledger CSV files here</div>
        <div className="text-xs text-muted-foreground">
          Expected columns: Rekening, Periode, Datum, Boeknummer, Trek, Debet, Credit, Boekingstekst, Dagboek, BTW, BTW-srt
        </div>
        <label className="mt-3 inline-flex cursor-pointer items-center gap-2 rounded-sm border border-border px-3 py-1.5 text-xs hover:bg-accent">
          <FileText className="h-3.5 w-3.5" /> Choose file
          <input
            type="file"
            accept=".csv,text/csv"
            multiple
            className="hidden"
            onChange={(e) => e.target.files && handleFiles(e.target.files)}
          />
        </label>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="text-xs text-muted-foreground">
          {connection ? "Files will be tagged with this connection." : "No active connection — files will be ingested as manual uploads."}
        </div>
        <Button variant="outline" size="sm" onClick={handlePullFromYuki} disabled={busy || !connection}>
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          Pull from Yuki
        </Button>
      </div>
    </section>
  );
}

function SyncHistory({ runs, loading }: { runs: SyncRun[]; loading: boolean }) {
  return (
    <section className="rounded-lg border border-border bg-card">
      <header className="flex items-center justify-between border-b border-border px-6 py-4">
        <h2 className="font-serif text-xl">Sync history</h2>
        <div className="text-xs text-muted-foreground">{runs.length} record{runs.length === 1 ? "" : "s"}</div>
      </header>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-6 py-3 text-left">File</th>
              <th className="px-3 py-3 text-left">Source</th>
              <th className="px-3 py-3 text-left">Status</th>
              <th className="px-3 py-3 text-right">Rows</th>
              <th className="px-3 py-3 text-right">Failed</th>
              <th className="px-3 py-3 text-right">Debet €</th>
              <th className="px-3 py-3 text-right">Credit €</th>
              <th className="px-3 py-3 text-left">Period</th>
              <th className="px-6 py-3 text-left">Started</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={9} className="px-6 py-8 text-center text-muted-foreground">
                  <Loader2 className="mx-auto h-4 w-4 animate-spin" />
                </td>
              </tr>
            ) : runs.length === 0 ? (
              <tr>
                <td colSpan={9} className="px-6 py-12 text-center text-muted-foreground">
                  No ledger files received yet. Authorize Yuki or drop a CSV above.
                </td>
              </tr>
            ) : (
              runs.map((r) => (
                <tr key={r.id} className="border-t border-border hover:bg-muted/20">
                  <td className="px-6 py-3 font-mono text-xs">{r.file_name}</td>
                  <td className="px-3 py-3 text-xs uppercase tracking-wider text-muted-foreground">{r.source}</td>
                  <td className="px-3 py-3"><StatusBadge status={r.status} message={r.error_message} /></td>
                  <td className="px-3 py-3 text-right tabular-nums">{r.rows_processed}</td>
                  <td className="px-3 py-3 text-right tabular-nums text-muted-foreground">{r.rows_failed}</td>
                  <td className="px-3 py-3 text-right tabular-nums">{fmtEUR(r.total_debet)}</td>
                  <td className="px-3 py-3 text-right tabular-nums">{fmtEUR(r.total_credit)}</td>
                  <td className="px-3 py-3 text-xs text-muted-foreground">
                    {r.period_start && r.period_end ? `${r.period_start} → ${r.period_end}` : "—"}
                  </td>
                  <td className="px-6 py-3 text-xs text-muted-foreground">{new Date(r.started_at).toLocaleString()}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function StatusBadge({ status, message }: { status: string; message: string | null }) {
  const styles: Record<string, string> = {
    pending: "border-amber-500/40 bg-amber-500/10 text-amber-400",
    processing: "border-sky-500/40 bg-sky-500/10 text-sky-400",
    completed: "border-emerald-500/40 bg-emerald-500/10 text-emerald-400",
    failed: "border-destructive/40 bg-destructive/10 text-destructive",
  };
  return (
    <span
      title={message ?? undefined}
      className={`inline-flex items-center gap-1 rounded-sm border px-2 py-0.5 text-xs uppercase tracking-wider ${styles[status] ?? "border-border"}`}
    >
      {status === "failed" && <AlertCircle className="h-3 w-3" />}
      {status === "processing" && <Loader2 className="h-3 w-3 animate-spin" />}
      {status}
    </span>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span>{value}</span>
    </div>
  );
}

function fmtEUR(v: number | string | null) {
  const n = typeof v === "string" ? Number(v) : v ?? 0;
  if (!Number.isFinite(n)) return "—";
  return new Intl.NumberFormat("en-IE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n);
}

