import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { fetchWeather, REGION_COORDS } from "@/lib/weather";
import { CloudRain, Wind, Thermometer } from "lucide-react";

export const Route = createFileRoute("/weather")({
  head: () => ({
    meta: [
      { title: "Weather Outlook · Altis Groep" },
      { name: "description", content: "13-week weather outlook for Andijk and Winschoten operating regions powered by KNMI/Open-Meteo." },
    ],
  }),
  component: WeatherPage,
});

function WeatherPage() {
  const today = new Date();
  const end = new Date(today); end.setDate(end.getDate() + 91);
  const startISO = today.toISOString().slice(0, 10);
  const endISO = end.toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs uppercase tracking-[0.3em] text-primary">Weather Outlook</div>
        <h1 className="mt-1 font-serif text-4xl font-semibold">13-Week Working-Day Outlook</h1>
        <p className="mt-2 text-sm text-muted-foreground">KNMI / Open-Meteo · Andijk & Winschoten · Adverse = precip &gt; 10mm or wind &gt; 50 km/h</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {(["Andijk", "Winschoten"] as const).map((r) => (
          <RegionPanel key={r} region={r} startISO={startISO} endISO={endISO} />
        ))}
      </div>
    </div>
  );
}

function RegionPanel({ region, startISO, endISO }: { region: "Andijk" | "Winschoten"; startISO: string; endISO: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["wx", region, startISO, endISO],
    queryFn: () => fetchWeather(region, startISO, endISO),
  });
  const coords = REGION_COORDS[region];
  const bad = data?.filter((d) => d.precip > 10 || d.wind > 50) ?? [];
  const totalWork = data?.filter((d) => {
    const dow = new Date(d.date).getDay();
    return dow !== 0 && dow !== 6;
  }).length ?? 0;
  const badWork = bad.filter((d) => {
    const dow = new Date(d.date).getDay();
    return dow !== 0 && dow !== 6;
  }).length;

  return (
    <div className="rounded-md border border-border bg-card p-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-serif text-xl font-semibold">{region}</div>
          <div className="text-xs text-muted-foreground">{coords.lat.toFixed(2)}°N, {coords.lon.toFixed(2)}°E</div>
        </div>
        <div className="text-right">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Adverse Working Days</div>
          <div className="font-serif text-2xl text-primary">{badWork} / {totalWork}</div>
        </div>
      </div>
      {isLoading ? (
        <div className="mt-6 text-sm text-muted-foreground">Loading forecast…</div>
      ) : (
        <div className="mt-4 max-h-[480px] overflow-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-card text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-2 py-1.5 text-left">Date</th>
                <th className="px-2 py-1.5 text-right"><CloudRain className="ml-auto h-3 w-3" /></th>
                <th className="px-2 py-1.5 text-right"><Wind className="ml-auto h-3 w-3" /></th>
                <th className="px-2 py-1.5 text-right"><Thermometer className="ml-auto h-3 w-3" /></th>
                <th className="px-2 py-1.5 text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {data?.slice(0, 60).map((d) => {
                const adverse = d.precip > 10 || d.wind > 50;
                const dow = new Date(d.date).getDay();
                const weekend = dow === 0 || dow === 6;
                return (
                  <tr key={d.date} className="border-b border-border/40">
                    <td className="px-2 py-1 font-mono">{d.date}</td>
                    <td className={`px-2 py-1 text-right font-mono ${d.precip > 10 ? "text-destructive" : ""}`}>{d.precip.toFixed(1)}mm</td>
                    <td className={`px-2 py-1 text-right font-mono ${d.wind > 50 ? "text-destructive" : ""}`}>{d.wind.toFixed(0)}</td>
                    <td className="px-2 py-1 text-right font-mono text-muted-foreground">{d.tmin.toFixed(0)}/{d.tmax.toFixed(0)}°</td>
                    <td className="px-2 py-1 text-right">
                      {weekend ? <span className="text-muted-foreground">weekend</span> :
                       adverse ? <span className="text-destructive">⚠ adverse</span> :
                       <span className="text-primary">✓ workable</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
