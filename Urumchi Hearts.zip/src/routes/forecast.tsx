import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from "recharts";
import { buildForecast, buildInsights, formatEUR, monthLabel, months, revenue, collections as collectionsFor, type Region } from "@/lib/altis-data";
import { fetchScenarioWeather, fetchHistoricalWeather, isAdverseDay, SCENARIO_PRESETS, scenarioLabel, type Scenario, type ScenarioMode, type PresetKey } from "@/lib/weather";
import { AlertTriangle, Info, AlertCircle, CloudRain, ChevronDown, ChevronRight } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PortfolioPanel } from "@/components/PortfolioPanel";
import { CfoSummary } from "@/components/CfoSummary";
import { computeSummaryFacts } from "@/lib/cfo-summary";

export const Route = createFileRoute("/forecast")({
  head: () => ({
    meta: [
      { title: "CFO Dashboard · Altis Groep" },
      { name: "description", content: "Weather-aware 13-week rolling cash-flow forecast with KNMI/Open-Meteo working-day adjustment, reconciled against Yuki GL line items." },
    ],
  }),
  component: ForecastPage,
});


const REGIONS: Region[] = ["Company", "Andijk", "Winschoten"];

function ForecastPage() {
  const [region, setRegion] = useState<Region>("Company");
  const [startCash] = useState(850_000);
  const [drillWeek, setDrillWeek] = useState<number | null>(null);
  const [scenario, setScenario] = useState<Scenario>({ mode: "live", adverseDays: 0 });
  const [methodOpen, setMethodOpen] = useState(false);

  const { data: weather, isLoading: weatherLoading } = useQuery({
    queryKey: ["scenarioWeather", region, scenario],
    queryFn: () => fetchScenarioWeather(region === "Company" ? "Company" : region, scenario),
  });

  const weatherMap = useMemo(() => {
    const m = new Map<string, { precip: number; wind: number; tmax?: number; tmin?: number; weatherCode?: number }>();
    weather?.forEach((d) => m.set(d.date, { precip: d.precip, wind: d.wind, tmax: d.tmax, tmin: d.tmin, weatherCode: d.weatherCode }));
    return m;
  }, [weather]);

  const weeks = useMemo(() => buildForecast(region, startCash, weatherMap), [region, startCash, weatherMap]);
  const insights = useMemo(() => buildInsights(weeks, region), [weeks, region]);

  const histStart = months[0] + "-01";
  const histEnd = (() => {
    const [y, m] = months[months.length - 1].split("-").map(Number);
    const last = new Date(y, m, 0); // last day of month
    return last.toISOString().slice(0, 10);
  })();

  const { data: histWeather } = useQuery({
    queryKey: ["histWeather", region, histStart, histEnd],
    queryFn: () => fetchHistoricalWeather(region === "Company" ? "Company" : region, histStart, histEnd),
    staleTime: Infinity,
  });

  const history = useMemo(() => {
    // Aggregate adverse vs workable days per month from historical weather
    const adverseByMonth = new Map<string, number>();
    const workableByMonth = new Map<string, number>();
    const workingByMonth = new Map<string, number>();
    (histWeather ?? []).forEach((d) => {
      const ym = d.date.slice(0, 7);
      const dow = new Date(d.date).getDay();
      if (dow === 0 || dow === 6) return;
      workingByMonth.set(ym, (workingByMonth.get(ym) ?? 0) + 1);
      if (isAdverseDay(d)) {
        adverseByMonth.set(ym, (adverseByMonth.get(ym) ?? 0) + 1);
      } else {
        workableByMonth.set(ym, (workableByMonth.get(ym) ?? 0) + 1);
      }
    });
    return months.map((m) => {
      const rev = revenue(region, m);
      const coll = region === "Company" ? collectionsFor(m) : rev * 0.85;
      return {
        ym: m,
        label: monthLabel(m),
        Revenue: Math.round(rev),
        Collections: Math.round(coll),
        AdverseDays: adverseByMonth.get(m) ?? 0,
        WorkableDays: workableByMonth.get(m) ?? 0,
        WorkingDays: workingByMonth.get(m) ?? 0,
      };
    });
  }, [region, histWeather]);


  const COVENANT_THRESHOLD = 250_000;
  const minCash = Math.min(...weeks.map((w) => w.cumulativeCash));
  const endCash = weeks[weeks.length - 1]?.cumulativeCash ?? 0;
  const totalWeather = weeks.reduce((a, b) => a + b.weatherAdj, 0);
  const headroom = minCash - COVENANT_THRESHOLD;
  const headroomPct = COVENANT_THRESHOLD > 0 ? (headroom / COVENANT_THRESHOLD) * 100 : 0;
  const covenantTone: "good" | "warn" | "bad" = headroom < 0 ? "bad" : headroomPct < 25 ? "warn" : "good";
  const breachWeek = weeks.find((w) => w.cumulativeCash < COVENANT_THRESHOLD);

  const weeksChart = useMemo(
    () =>
      weeks.map((w) => {
        const d = new Date(w.weekStart);
        const dd = String(d.getDate()).padStart(2, "0");
        const mm = String(d.getMonth() + 1).padStart(2, "0");
        return { ...w, xLabel: `W${w.weekIdx} · ${dd}/${mm}` };
      }),
    [weeks],
  );



  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-[0.3em] text-primary">CFO Dashboard</div>
          <h1 className="mt-1 font-serif text-4xl font-semibold">Weather-Aware Cash Flow</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Portfolio performance · 13-week rolling forecast · KNMI/Open-Meteo working-day adjustment · {region}
          </p>
        </div>

        <div className="flex items-center gap-3">
          
          <div className="flex rounded-sm border border-border bg-card p-1">
            {REGIONS.map((r) => (
              <button
                key={r}
                onClick={() => setRegion(r)}
                className={`px-4 py-1.5 text-xs uppercase tracking-wider transition-colors ${
                  region === r ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      <ScenarioToolbar scenario={scenario} setScenario={setScenario} loading={weatherLoading} />

      <CfoSummary
        facts={computeSummaryFacts(weeks, region, scenarioLabel(scenario), startCash)}
      />



      <div className="grid grid-cols-5 gap-4">
        <KPI label="End-of-Period Cash" value={formatEUR(endCash)} tone={endCash > startCash ? "good" : "bad"} sub={`vs ${formatEUR(startCash)} start`} />
        <KPI label="Cash Trough (low point)" value={formatEUR(minCash)} tone={minCash < COVENANT_THRESHOLD ? "bad" : "good"} sub="Min cumulative balance" />
        <KPI
          label="Covenant Headroom"
          value={`${headroom >= 0 ? "+" : ""}${formatEUR(headroom)}`}
          tone={covenantTone}
          sub={`${headroomPct >= 0 ? "+" : ""}${headroomPct.toFixed(0)}% vs €250k floor`}
        />
        <KPI label="Weather Drag" value={formatEUR(totalWeather)} tone="warn" sub={weatherLoading ? "loading…" : `${weeks.reduce((a, b) => a + b.badWeatherDays, 0)} adverse days`} />
        <KPI label="Forecast Revenue" value={formatEUR(weeks.reduce((a, b) => a + b.forecastRevenue, 0))} tone="neutral" sub="13-week total" />
      </div>

      {breachWeek && (
        <div className="flex items-start gap-3 rounded-md border-l-4 border-destructive bg-destructive/10 px-5 py-4">
          <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
          <div className="text-sm">
            <div className="font-medium text-destructive">Covenant breach risk</div>
            <div className="mt-0.5 text-foreground/90">
              Week {breachWeek.weekIdx} ({breachWeek.weekStart}) projects cumulative cash of {formatEUR(breachWeek.cumulativeCash)} — below the €250k covenant floor.
              Minimum across the horizon: <span className="font-mono">{formatEUR(minCash)}</span>. Consider drawing on the RCF or accelerating collections on the largest Yuki open invoices.
            </div>
          </div>
        </div>
      )}

      <div className="rounded-md border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div>
            <div className="font-serif text-lg font-semibold">13-Week Cash Bridge</div>
            <div className="text-xs text-muted-foreground">Click any week for drill-down · {scenarioLabel(scenario)}</div>
          </div>
          <div className="text-xs text-muted-foreground">€250k covenant threshold</div>
        </div>
        <div className="h-[420px] p-4">
          <ResponsiveContainer>
            <ComposedChart data={weeksChart} onClick={(e) => e?.activeLabel && setDrillWeek(Number(String(e.activeLabel).match(/W(\d+)/)?.[1] ?? 0))}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.30 0.03 260)" />
              <XAxis dataKey="xLabel" stroke="oklch(0.72 0.025 80)" fontSize={11} interval={0} angle={-30} textAnchor="end" height={60} label={{ value: "Week · start date", position: "insideBottom", offset: -5, fill: "oklch(0.72 0.025 80)" }} />
              <YAxis stroke="oklch(0.72 0.025 80)" fontSize={11} tickFormatter={(v) => formatEUR(v)} />
              <Tooltip
                contentStyle={{ backgroundColor: "oklch(0.21 0.035 260)", border: "1px solid oklch(0.30 0.03 260)", borderRadius: 4 }}
                formatter={(v: number) => formatEUR(v)}
              />
              <Legend verticalAlign="top" align="right" wrapperStyle={{ fontSize: 12, paddingBottom: 8 }} />
              <ReferenceLine y={250000} stroke="oklch(0.62 0.22 27)" strokeDasharray="4 4" />
              <Bar dataKey="collections" name="Collections" fill="oklch(0.70 0.14 160)" cursor="pointer" />
              <Bar dataKey="materialsSubs" name="Materials & Subs" stackId="out" fill="oklch(0.55 0.18 30)" cursor="pointer" />
              <Bar dataKey="payroll" name="Payroll" stackId="out" fill="oklch(0.50 0.14 300)" cursor="pointer" />
              <Bar dataKey="overhead" name="Overhead" stackId="out" fill="oklch(0.55 0.06 260)" cursor="pointer" />
              <Bar dataKey="taxRemit" name="BTW / Payroll Tax" stackId="out" fill="oklch(0.45 0.10 20)" cursor="pointer" />
              <Line type="monotone" dataKey="cumulativeCash" name="Cumulative Cash" stroke="oklch(0.78 0.13 85)" strokeWidth={3} dot={{ r: 4 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-md border border-border bg-card p-6">
        <button
          type="button"
          onClick={() => setMethodOpen((v) => !v)}
          className="flex w-full items-start justify-between gap-4 text-left"
          aria-expanded={methodOpen}
        >
          <div>
            <div className="font-serif text-lg font-semibold">How the 13-week forecast is calculated</div>
            <div className="mt-1 text-xs text-muted-foreground">Deterministic, weather-aware bottom-up build · reproducible from Yuki actuals + Open-Meteo</div>
          </div>
          {methodOpen ? <ChevronDown className="mt-1 h-5 w-5 text-muted-foreground" /> : <ChevronRight className="mt-1 h-5 w-5 text-muted-foreground" />}
        </button>
        {methodOpen && (
        <>
        <ol className="mt-4 space-y-3 text-sm text-foreground/90 list-decimal pl-5">
          <li>
            <span className="font-medium">Baseline revenue per working day.</span>{" "}
            Take the trailing 6 months of reconciled Yuki revenue for the selected entity (Company / Andijk / Winschoten),
            average them, and divide by 21 working days/month to get
            <code className="mx-1 rounded bg-muted px-1 py-0.5 font-mono text-xs">trailingDailyRev = Σ(last 6 months revenue) / 6 / 21</code>.
          </li>
          <li>
            <span className="font-medium">Seasonality factor.</span> Multiply by a month-of-year coefficient calibrated on
            historical roofing patterns — winter low (Dec–Feb ≈ 0.78–0.85), spring/summer build (Apr–Jul ≈ 1.08–1.15),
            Dutch holiday dip (Aug ≈ 0.70), autumn peak (Sep–Oct ≈ 1.15–1.18).
          </li>
          <li>
            <span className="font-medium">Weather working-day adjustment.</span> For each of the 13 forward weeks, fetch the
            Open-Meteo forecast for the region's site. A day counts as <em>adverse</em> if any of the workable criteria fail
            (wind ≥10 m/s, temp outside 0–29 °C, visibility &lt;50 m, frost/snow/flooding, thunderstorm within 10 km, Beaufort ≥6).
            Each adverse day reduces that week's effective working days by 0.7 (crews still mobilise, ~30% recovery on partial days).
            <code className="mx-1 rounded bg-muted px-1 py-0.5 font-mono text-xs">effectiveDays = workingDays − 0.7 × adverseDays</code>.
          </li>
          <li>
            <span className="font-medium">Forecast revenue (varies by week).</span>{" "}
            <code className="mx-1 rounded bg-muted px-1 py-0.5 font-mono text-xs">forecastRevenue = trailingDailyRev × effectiveDays × seasonality × weekOfMonth × jobTimingFactor</code>.
            Week-of-month profile [0.92, 1.05, 1.08, 0.98, 0.85] models crew ramp-up/taper; the{" "}
            <em>job-start timing factor</em> (deterministic ±12% pipeline lumpiness — captures the reality
            that jobs rarely start evenly across weeks: one week three crews mobilise, the next week one)
            adds week-to-week variation. The <em>Weather Drag</em> KPI is the delta versus the unweathered baseline.
          </li>
          <li>
            <span className="font-medium">Collections (lagged, varies).</span> Collections in week <em>w</em> draw from
            invoiced revenue ~6 weeks earlier (DSO ≈ 6 wk) at a 92% realisation rate. Weeks 1–6 pull from historical Yuki
            monthly revenue (so early-week collections reflect actuals, not the forecast); weeks 7–13 lag the forecast.
          </li>
          <li>
            <span className="font-medium">Outflows (componentised, varies).</span> Weekly = fixed payroll (≈22% of
            trailing monthly revenue / 4.33) + overhead (≈6% / 4.33) + materials &amp; subs (38% of <em>that week's</em>
            forecast revenue) + a BTW / payroll-tax remittance spike (≈14% of prior month revenue) booked into the
            last week of each month. Net cash flow = collections − outflows, accumulated from <em>Start cash</em>.
          </li>
          <li>
            <span className="font-medium">Insights.</span> Rule-based alerts fire when cumulative cash dips below the €250k
            covenant threshold, when ≥3 weeks show net outflow, or when adverse days exceed 8 of the 65 forecast working days.
          </li>
        </ol>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
          <WorkedExample week={weeks[0]} title="Worked example · Week 1 (early)" subtitle="Collections sourced from historical Yuki actuals (DSO ≈ 6 wk)" />
          <WorkedExample week={weeks[9]} title="Worked example · Week 10 (later)" subtitle="Collections lag W4 forecast (6-week DSO into the forecast)" footnote="W10 collections inherit earlier-week forecast revenue — this is exactly the DSO lag the bridge is built to surface." />
        </div>
        </>
        )}
      </div>



      <PortfolioPanel region={region} />


      <div className="rounded-md border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div>
            <div className="font-serif text-lg font-semibold">Historical Revenue vs Workable &amp; Adverse Days — {region}</div>
            <div className="text-xs text-muted-foreground">
              Workable = wind &lt;10 m/s, 0–29 °C, visibility &gt;50 m, no frost/snow/flood, no thunderstorm, Beaufort &lt;6 · Open-Meteo archive
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            {histWeather ? `${(histWeather ?? []).length} days of historical weather` : "loading archive…"}
          </div>
        </div>
        <div className="h-[320px] p-4">
          <ResponsiveContainer>
            <ComposedChart data={history}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.30 0.03 260)" />
              <XAxis dataKey="label" stroke="oklch(0.72 0.025 80)" fontSize={10} interval={2} />
              <YAxis yAxisId="left" stroke="oklch(0.72 0.025 80)" fontSize={11} tickFormatter={(v) => formatEUR(v)} />
              <YAxis yAxisId="right" orientation="right" stroke="oklch(0.72 0.025 80)" fontSize={11} label={{ value: "Days", angle: 90, position: "insideRight", fill: "oklch(0.72 0.025 80)", fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: "oklch(0.21 0.035 260)", border: "1px solid oklch(0.30 0.03 260)", borderRadius: 4 }}
                formatter={(v: number, name: string) => name === "Revenue" ? formatEUR(v) : `${v} days`}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar yAxisId="left" dataKey="Revenue" fill="oklch(0.78 0.13 85)" />
              <Bar yAxisId="right" dataKey="WorkableDays" stackId="days" fill="oklch(0.70 0.14 160)" opacity={0.75} />
              <Bar yAxisId="right" dataKey="AdverseDays" stackId="days" fill="oklch(0.62 0.22 27)" opacity={0.75} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>


      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 rounded-md border border-border bg-card p-6">
          <div className="font-serif text-lg font-semibold">Week-by-week breakdown</div>
          <div className="mt-4 overflow-auto">
            <table className="w-full text-xs">
              <thead className="text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="px-2 py-2 text-left">Wk</th>
                  <th className="px-2 py-2 text-left">Starting</th>
                  <th className="px-2 py-2 text-right">Forecast Rev</th>
                  <th className="px-2 py-2 text-right">Collections</th>
                  <th className="px-2 py-2 text-right" title="Materials & Subcontractors">Mat. & Subs</th>
                  <th className="px-2 py-2 text-right">Payroll</th>
                  <th className="px-2 py-2 text-right">Overhead</th>
                  <th className="px-2 py-2 text-right" title="BTW / Payroll tax remittance">BTW</th>
                  <th className="px-2 py-2 text-right">Net</th>
                  <th className="px-2 py-2 text-right">Cum. Cash</th>
                  <th className="px-2 py-2 text-center">Wx</th>
                </tr>
              </thead>
              <tbody>
                {weeks.map((w) => (
                  <tr key={w.weekIdx} className="cursor-pointer border-b border-border/50 hover:bg-muted/40" onClick={() => setDrillWeek(w.weekIdx)}>
                    <td className="px-2 py-1.5 font-mono">{w.weekIdx}</td>
                    <td className="px-2 py-1.5 font-mono text-muted-foreground">{w.weekStart}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{formatEUR(w.forecastRevenue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-emerald-400">{formatEUR(w.collections)}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-destructive/80">{formatEUR(w.materialsSubs)}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-destructive/80">{formatEUR(w.payroll)}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-destructive/80">{formatEUR(w.overhead)}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-destructive/80">{w.taxRemit > 0 ? formatEUR(w.taxRemit) : "—"}</td>
                    <td className={`px-2 py-1.5 text-right font-mono ${w.netCashFlow >= 0 ? "text-primary" : "text-destructive"}`}>{formatEUR(w.netCashFlow)}</td>
                    <td className={`px-2 py-1.5 text-right font-mono ${w.cumulativeCash < 250000 ? "text-destructive" : ""}`}>{formatEUR(w.cumulativeCash)}</td>
                    <td className="px-2 py-1.5 text-center">
                      {w.badWeatherDays > 0 && <span className="inline-flex items-center gap-0.5 text-destructive"><CloudRain className="h-3 w-3" />{w.badWeatherDays}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-md border border-border bg-card p-6">
          <div className="font-serif text-lg font-semibold">CFO Insights</div>
          <div className="mt-1 text-xs text-muted-foreground">Rule-based, deterministic</div>
          <div className="mt-4 space-y-3">
            {insights.length === 0 && <div className="text-sm text-muted-foreground">No anomalies detected.</div>}
            {insights.map((ins, i) => (
              <div key={i} className={`rounded-sm border-l-2 bg-muted/30 p-3 ${
                ins.severity === "critical" ? "border-destructive" :
                ins.severity === "warn" ? "border-primary" : "border-chart-2"
              }`}>
                <div className="flex items-center gap-2 text-sm font-medium">
                  {ins.severity === "critical" ? <AlertCircle className="h-4 w-4 text-destructive" /> :
                   ins.severity === "warn" ? <AlertTriangle className="h-4 w-4 text-primary" /> :
                   <Info className="h-4 w-4 text-chart-2" />}
                  {ins.title}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{ins.detail}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <WeekDrill
        week={drillWeek !== null ? weeks.find((w) => w.weekIdx === drillWeek) ?? null : null}
        weather={weather ?? []}
        scenario={scenario}
        region={region}
        startCash={startCash}
        threshold={COVENANT_THRESHOLD}
        onClose={() => setDrillWeek(null)}
      />
    </div>
  );
}

function KPI({ label, value, sub, tone }: { label: string; value: string; sub: string; tone: "good" | "bad" | "warn" | "neutral" }) {
  const color = tone === "good" ? "text-primary" : tone === "bad" ? "text-destructive" : tone === "warn" ? "text-chart-4" : "text-foreground";
  return (
    <div className="rounded-md border border-border bg-card p-5">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-3 font-serif text-3xl font-semibold ${color}`}>{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">{sub}</div>
    </div>
  );
}

function WeekDrill({ week, weather, scenario, region, startCash, threshold, onClose }: { week: any; weather: any[]; scenario: Scenario; region: Region; startCash: number; threshold: number; onClose: () => void }) {
  if (!week) return null;
  const weekWeather = weather.filter((d) => {
    const dd = new Date(d.date);
    const ws = new Date(week.weekStart);
    return dd >= ws && dd < new Date(ws.getTime() + 7 * 86400000);
  });
  const breach = week.cumulativeCash < threshold;
  return (
    <Dialog open={!!week} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] max-w-4xl overflow-y-auto border-border bg-card text-foreground">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">Week {week.weekIdx} · {week.weekStart}</DialogTitle>
          <div className="text-xs text-muted-foreground">Traceability: every figure → driver → assumption → toggle → source</div>
        </DialogHeader>

        <div className="grid grid-cols-3 gap-3">
          <Stat label="Forecast Revenue" value={formatEUR(week.forecastRevenue)} />
          <Stat label="Collections" value={formatEUR(week.collections)} tone="good" />
          <Stat label="Outflows" value={formatEUR(week.outflows)} tone="bad" />
          <Stat label="Net Cash Flow" value={formatEUR(week.netCashFlow)} tone={week.netCashFlow >= 0 ? "good" : "bad"} />
          <Stat label="Cum. Cash" value={formatEUR(week.cumulativeCash)} tone={breach ? "bad" : undefined} />
          <Stat label="Working Days" value={`${week.workingDays - week.badWeatherDays} (${week.badWeatherDays} adverse)`} />
        </div>

        {breach && (
          <div className="rounded-sm border-l-2 border-destructive bg-destructive/10 px-3 py-2 text-xs text-destructive">
            Cumulative cash {formatEUR(week.cumulativeCash)} is below the €{(threshold / 1000).toFixed(0)}k covenant floor.
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-sm border border-border">
            <div className="border-b border-border bg-muted/30 px-3 py-2 text-xs uppercase tracking-wider text-muted-foreground">Driver breakdown</div>
            <table className="w-full text-xs font-mono">
              <tbody>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Materials & Subcontractors (38% × forecast rev)</td><td className="px-2 py-1 text-right">{formatEUR(week.materialsSubs)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Payroll (22% trailing mo / 4.33)</td><td className="px-2 py-1 text-right">{formatEUR(week.payroll)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Overhead (6% trailing mo / 4.33)</td><td className="px-2 py-1 text-right">{formatEUR(week.overhead)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">BTW / Payroll tax {week.isMonthEndWeek ? "(month-end)" : "(n/a)"}</td><td className="px-2 py-1 text-right">{week.taxRemit > 0 ? formatEUR(week.taxRemit) : "—"}</td></tr>
                <tr className="border-t border-border"><td className="px-2 py-1.5 font-medium">Collections (DSO ≈ 6 wk × 92%)</td><td className="px-2 py-1.5 text-right text-primary">{formatEUR(week.collections)}</td></tr>
              </tbody>
            </table>
          </div>

          <div className="rounded-sm border border-border">
            <div className="border-b border-border bg-muted/30 px-3 py-2 text-xs uppercase tracking-wider text-muted-foreground">Assumptions & inputs</div>
            <table className="w-full text-xs font-mono">
              <tbody>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Trailing daily revenue</td><td className="px-2 py-1 text-right">{formatEUR(week.trailingDailyRev)}/day</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Seasonality</td><td className="px-2 py-1 text-right">× {week.seasonality.toFixed(2)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Week-of-month (w{week.weekOfMonth})</td><td className="px-2 py-1 text-right">× {week.womFactor.toFixed(2)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Job-start timing (±12%)</td><td className="px-2 py-1 text-right">× {week.jobTimingFactor.toFixed(2)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Effective days (work − 0.7×adv)</td><td className="px-2 py-1 text-right">{week.effectiveDays.toFixed(2)}</td></tr>
                <tr className="border-t border-border/50"><td className="px-2 py-1 text-muted-foreground">Weather drag vs baseline</td><td className={`px-2 py-1 text-right ${week.weatherAdj < 0 ? "text-destructive" : ""}`}>{formatEUR(week.weatherAdj)}</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-sm border border-border">
          <div className="border-b border-border bg-muted/30 px-3 py-2 text-xs uppercase tracking-wider text-muted-foreground">Source & toggle state</div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 px-3 py-3 text-xs">
            <div className="text-muted-foreground">Collections source</div><div className="font-mono">{week.collectionsSourceLabel} → {formatEUR(week.collectionsSource)}</div>
            <div className="text-muted-foreground">Entity (region toggle)</div><div className="font-mono">{region}</div>
            <div className="text-muted-foreground">Start cash (input)</div><div className="font-mono">{formatEUR(startCash)}</div>
            <div className="text-muted-foreground">Weather scenario</div><div className="font-mono">{scenarioLabel(scenario)}</div>
            <div className="text-muted-foreground">Covenant threshold</div><div className="font-mono">{formatEUR(threshold)}</div>
            <div className="text-muted-foreground">Data source</div><div className="font-mono">Yuki GL ledgers (reconciled) + Open-Meteo</div>
          </div>
        </div>
        <div className="rounded-sm border border-border">
          <div className="border-b border-border bg-muted/30 px-3 py-2 text-xs uppercase tracking-wider text-muted-foreground">Daily weather (KNMI / Open-Meteo)</div>
          <table className="w-full text-xs">
            <thead className="text-muted-foreground">
              <tr><th className="px-2 py-1 text-left">Date</th><th className="px-2 py-1 text-right">Precip mm</th><th className="px-2 py-1 text-right">Wind km/h</th><th className="px-2 py-1 text-right">Min/Max °C</th><th className="px-2 py-1 text-right">Work?</th></tr>
            </thead>
            <tbody>
              {weekWeather.map((d) => {
                const bad = isAdverseDay(d);
                const dow = new Date(d.date).getDay();
                const weekend = dow === 0 || dow === 6;
                return (
                  <tr key={d.date} className="border-t border-border/50">
                    <td className="px-2 py-1 font-mono">{d.date}</td>
                    <td className={`px-2 py-1 text-right font-mono ${d.precip > 25 ? "text-destructive" : ""}`}>{d.precip.toFixed(1)}</td>
                    <td className={`px-2 py-1 text-right font-mono ${d.wind >= 36 ? "text-destructive" : ""}`}>{d.wind.toFixed(0)}</td>
                    <td className="px-2 py-1 text-right font-mono text-muted-foreground">{d.tmin.toFixed(0)} / {d.tmax.toFixed(0)}</td>
                    <td className="px-2 py-1 text-right">{weekend ? "—" : bad ? "⚠" : "✓"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "good" | "bad" }) {
  const color = tone === "good" ? "text-primary" : tone === "bad" ? "text-destructive" : "";
  return (
    <div className="rounded-sm border border-border bg-muted/30 p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 font-mono text-base ${color}`}>{value}</div>
    </div>
  );
}

function WorkedExample({ week, title, subtitle, footnote }: { week: any; title: string; subtitle: string; footnote?: string }) {
  if (!week) return null;
  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const mName = monthNames[week.monthIdx];
  const fmt = (n: number) => formatEUR(Math.round(n));
  const fmt2 = (n: number) => n.toFixed(2);
  return (
    <div className="rounded-sm border border-border bg-muted/20 p-4">
      <div className="text-xs uppercase tracking-wider text-primary">{title}</div>
      <div className="mt-1 text-sm font-medium">{subtitle}</div>
      <table className="mt-3 w-full text-xs">
        <tbody className="font-mono">
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Week start</td><td className="py-1 text-right">{week.weekStart}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">trailingDailyRev (last 6 mo / 6 / 21)</td><td className="py-1 text-right">{fmt(week.trailingDailyRev)} / day</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Seasonality ({mName})</td><td className="py-1 text-right">× {fmt2(week.seasonality)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Week-of-month (week {week.weekOfMonth} of {mName})</td><td className="py-1 text-right">× {fmt2(week.womFactor)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Job-start timing factor (±12% pipeline lumpiness)</td><td className="py-1 text-right">× {fmt2(week.jobTimingFactor)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Working days · adverse → effective</td><td className="py-1 text-right">{week.workingDays} · {week.badWeatherDays} → {fmt2(week.effectiveDays)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1">Forecast revenue = {Math.round(week.trailingDailyRev).toLocaleString()} × {fmt2(week.effectiveDays)} × {fmt2(week.seasonality)} × {fmt2(week.womFactor)} × {fmt2(week.jobTimingFactor)}</td><td className="py-1 text-right text-foreground">{fmt(week.forecastRevenue)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Weather drag vs no-adverse baseline</td><td className={`py-1 text-right ${week.weatherAdj < 0 ? "text-destructive" : ""}`}>{fmt(week.weatherAdj)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Collections source: {week.collectionsSourceLabel}</td><td className="py-1 text-right">{fmt(week.collectionsSource)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1">Collections = source × 0.92 realisation</td><td className="py-1 text-right text-primary">{fmt(week.collections)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Payroll (trailingMo × 22% / 4.33)</td><td className="py-1 text-right">{fmt(week.payroll)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Overhead (trailingMo × 6% / 4.33)</td><td className="py-1 text-right">{fmt(week.overhead)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">Materials &amp; subs (forecastRev × 38%)</td><td className="py-1 text-right">{fmt(week.materialsSubs)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1 text-muted-foreground">BTW / payroll-tax ({week.isMonthEndWeek ? "month-end week" : "not month-end week"})</td><td className="py-1 text-right">{fmt(week.taxRemit)}</td></tr>
          <tr className="border-b border-border/40"><td className="py-1">Outflows total</td><td className="py-1 text-right text-destructive">{fmt(week.outflows)}</td></tr>
          <tr><td className="py-1 font-medium">Net cash flow (W{week.weekIdx}) = collections − outflows</td><td className={`py-1 text-right font-medium ${week.netCashFlow >= 0 ? "text-primary" : "text-destructive"}`}>{fmt(week.netCashFlow)}</td></tr>
          <tr><td className="py-1 text-muted-foreground">Cumulative cash after W{week.weekIdx}</td><td className="py-1 text-right font-mono">{fmt(week.cumulativeCash)}</td></tr>
        </tbody>
      </table>
      {footnote && <div className="mt-2 text-[11px] text-muted-foreground">{footnote}</div>}
    </div>
  );
}

function ScenarioToolbar({ scenario, setScenario, loading }: { scenario: Scenario; setScenario: (s: Scenario) => void; loading: boolean }) {
  const modes: { key: ScenarioMode; label: string }[] = [
    { key: "live", label: "Live forecast" },
    { key: "preset", label: "Preset" },
    { key: "custom", label: "Custom date" },
    { key: "synthetic", label: "Stress test" },
  ];
  const todayMinus95 = (() => { const d = new Date(); d.setDate(d.getDate() - 95); return d.toISOString().slice(0, 10); })();

  return (
    <div className="rounded-md border border-border bg-card">
      <div className="flex flex-wrap items-center gap-3 border-b border-border px-6 py-3">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">Weather scenario</div>
        <div className="flex rounded-sm border border-border bg-background p-0.5">
          {modes.map((m) => (
            <button
              key={m.key}
              onClick={() => setScenario({ ...scenario, mode: m.key })}
              className={`px-3 py-1 text-xs transition-colors ${
                scenario.mode === m.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
        {loading && <div className="text-xs text-muted-foreground">loading weather…</div>}
        <div className="ml-auto text-xs text-muted-foreground">Swaps the forward weather input only — all other forecast assumptions held constant.</div>
      </div>

      <div className="px-6 py-4">
        {scenario.mode === "live" && (
          <div className="text-xs text-muted-foreground">
            Open-Meteo's actual 16-day forecast + Netherlands monthly climatology beyond day 16. This is the default operational view.
          </div>
        )}

        {scenario.mode === "preset" && (
          <div className="flex flex-wrap gap-2">
            {(Object.keys(SCENARIO_PRESETS) as PresetKey[]).map((k) => {
              const p = SCENARIO_PRESETS[k];
              const active = scenario.presetKey === k;
              return (
                <button
                  key={k}
                  onClick={() => setScenario({ ...scenario, mode: "preset", presetKey: k })}
                  className={`rounded-sm border px-3 py-2 text-left text-xs transition-colors ${
                    active ? "border-primary bg-primary/10 text-foreground" : "border-border bg-muted/30 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <div className="font-medium text-foreground">{p.label}</div>
                  <div className="mt-0.5 text-[11px] text-muted-foreground">{p.description}</div>
                </button>
              );
            })}
          </div>
        )}

        {scenario.mode === "custom" && (
          <div className="space-y-1.5">
            <label className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              Start date (we replay 91 days of archived weather from here):
              <input
                type="date"
                min="2022-01-01"
                max={todayMinus95}
                value={scenario.customStart ?? "2024-01-01"}
                onChange={(e) => setScenario({ ...scenario, mode: "custom", customStart: e.target.value })}
                className="rounded-sm border border-border bg-input px-2 py-1 font-mono text-sm text-foreground"
              />
            </label>
            <div className="text-[11px] text-muted-foreground">
              Latest allowed start: {todayMinus95} (so the full 13-week window fits in the archive). End date is derived automatically — no need to pick one.
              {scenario.customStart && (
                <> Using Open-Meteo archive precipitation, wind, temperature, and weather codes from <span className="font-mono">{scenario.customStart}</span> onward, mapped day-by-day onto the next 13 weeks.</>
              )}
            </div>
          </div>
        )}

        {scenario.mode === "synthetic" && (
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-3 text-xs text-muted-foreground">
              Adverse working days (next 13 weeks)
              <input
                type="number"
                min={0}
                max={65}
                step={1}
                value={scenario.adverseDays ?? 0}
                onChange={(e) => {
                  const n = Math.max(0, Math.min(65, Math.floor(Number(e.target.value) || 0)));
                  setScenario({ ...scenario, adverseDays: n });
                }}
                className="w-20 rounded-sm border border-border bg-input px-2 py-1 text-right font-mono text-sm text-foreground"
              />
              <span className="text-muted-foreground">/ 65 max</span>
            </label>
            <div className="text-[11px] text-muted-foreground">
              Forces exactly this many Mon–Fri days into adverse status, spread evenly across the 13-week window. Each one becomes a lost working day in the forecast.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}


