# Altis Groep — Weather-Aware CFO Dashboard

A Tier 1 prototype for the AI Hackathon Haarlem (Altis Groep challenge): a weather-aware **13-week cash flow forecast** for the CFO of a PE-backed Dutch roofing portfolio, reconciled from Yuki GL ledger exports and live KNMI / Open-Meteo weather data.

## What it delivers (Tier 1 — CFO Dashboard)

| # | Deliverable | Where it lives |
|---|---|---|
| 01 | Data ingestion from ≥1 accounting system → unified schema | Yuki ledgers (Andijk + Winschoten) parsed into `src/data/altis.json` and exposed via `src/lib/altis-data.ts` |
| 02 | 13-week week-by-week forecast separated by driver streams | Cash bridge chart + week table on `/forecast`; drivers split into Materials & Subs, Payroll, Overhead, BTW/Payroll Tax, Collections |
| 03 | Covenant headroom indicator | Dedicated KPI tile + breach banner above the cash bridge (€250k threshold) |
| 04 | Scenario toggle (base + adjustable) | `ScenarioToolbar` with Live / Preset / Custom-date / Synthetic-severity modes |
| 05 | Traceability — figure → driver → assumption → toggle → source | Click any week (chart or table) → `WeekDrill` dialog showing inputs, driver values, source month, toggle state |
| 06 | README with run instructions | This file |

Bonus already in scope: weather data integrated as a working-day adjustment (not a flat multiplier), and payment-lag (DSO ≈ 6 wk) modelled as a separate driver.

## Run it

```bash
bun install
bun dev
```

Then open the preview URL. The CFO Dashboard lives at `/forecast`.

## Architecture

```
src/
├── routes/
│   ├── __root.tsx              # TanStack Start root shell
│   ├── index.tsx               # redirects to /forecast
│   ├── forecast.tsx            # CFO Dashboard (this is the demo)
│   └── weather.tsx             # weather data sanity view
├── components/
│   ├── AppShell.tsx            # navigation + Yuki connect button
│   ├── ConnectYukiDialog.tsx   # Yuki connection UI
│   └── PortfolioPanel.tsx      # historical revenue + drill-down to GL line items
├── lib/
│   ├── altis-data.ts           # unified schema + 13-week forecast model
│   └── weather.ts              # Open-Meteo client + scenario engine
└── data/
    └── altis.json              # reconciled Yuki monthly totals + GL transactions
```

The architecture follows the brief's required separation:

```
ingestion (Yuki ledgers) → reconciliation (unified schema)
  → driver modelling (revenue, collections, materials, payroll, overhead, tax)
  → scenario generation (weather toggles)
  → role-based presentation (CFO Dashboard)
```

## Forecast methodology (summary)

1. **Baseline revenue per working day** — trailing 6 months Yuki revenue ÷ 6 ÷ 21 working days.
2. **Seasonality** — month-of-year coefficient (Aug 0.70× Dutch holiday, Sep–Oct 1.15–1.18× autumn peak, Dec–Feb winter low).
3. **Weather working-day adjustment** — Open-Meteo daily forecast classified adverse (wind ≥10 m/s, temp outside 0–29 °C, visibility <50 m, frost/snow/flood, thunderstorm, Beaufort ≥6). Each adverse day reduces effective days by 0.7.
4. **Forecast revenue** = `trailingDailyRev × effectiveDays × seasonality × weekOfMonth × jobTimingFactor` (job-start timing models pipeline lumpiness ±12%).
5. **Collections** — DSO ≈ 6 weeks at 92% realisation. Weeks 1–6 pull from historical Yuki monthly revenue (so early-week collections reflect actuals); weeks 7–13 lag the forecast.
6. **Outflows (componentised)** — Payroll 22% trailing mo / 4.33 + Overhead 6% / 4.33 + Materials & Subs 38% × forecast revenue + BTW / payroll-tax 14% of prior month booked in month-end week.
7. **Net cash** = collections − outflows, accumulated from `Start cash`.

All formulas are pure functions in `src/lib/altis-data.ts:buildForecast` — deterministic and reproducible.

## Data sources

- **Yuki accounting exports** (anonymised) — Andijk GB 8000/8001/8002 (Jan 2023 – May 2026) and Winschoten Dakdekkersbedrijf Peter Ummels FinTransactions (2023–2026). Reconciled into `src/data/altis.json` keyed by `YYYY-MM` per region with both monthly totals and GL line-item transactions for drill-down.
- **Open-Meteo** — free, no-key forecast (`https://api.open-meteo.com/v1/forecast`) and historical archive (`https://archive-api.open-meteo.com`). KNMI-compatible Dutch site coordinates per region (Andijk: 52.74°N, 5.18°E; Winschoten: 53.14°N, 7.03°E).

## Auditability walkthrough

To trace any number on the dashboard:

1. Click a bar/line on the **13-Week Cash Bridge**, or any row in the **Week-by-week breakdown**.
2. The `WeekDrill` dialog shows: the 6 driver values, the 6 input assumptions (trailing rev, seasonality, week-of-month factor, job timing, effective days, weather drag), the collections source month, and the current toggle state (region, start cash, weather scenario, covenant threshold).
3. For revenue and collections totals, the **Portfolio Performance** panel (`PortfolioPanel`) drills further to the underlying Yuki GL line items.

## Known limitations (Tier 1 scope)

- Only Yuki is reconciled. Gilde / Exact / Snelstart would be Tier 2.
- Single role (CFO). Opco MD and Project Lead views are Tier 2.
- No Dutch GAAP WIP / VAT periodisering treatment — Tier 3.
- LLM-assisted GL mapping not implemented — Tier 2/3 bonus.
- Weather-to-schedule translation is via working-day adjustment, not a per-project schedule shift.

## Hackathon data terms

All provided datasets are anonymised and licensed for hackathon use only. Per the brief, every copy will be deleted within 3 days of the event.
