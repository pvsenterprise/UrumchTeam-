## Single-slide pitch deck — Team Urumchi

Generate one hero slide (16:9, 13.333" × 7.5") as `/mnt/documents/urumchi_pitch.pptx` using pptxgenjs. Framing: **CFO pain → AI treasury copilot**, grounded in the actual product (Altis Groep, Yuki GL ingest, 13-week weather-adjusted forecast, AI-written CFO briefing).

### Slide layout

```text
┌──────────────────────────────────────────────────────────────────────┐
│  URUMCHI · ALTIS TREASURY INTELLIGENCE          [logo / wordmark]    │
│                                                                      │
│  The CFO's Monday-morning question                                   │
│  "Will we breach the €250k covenant in the next 13 weeks?"           │
│                                                                      │
│  ┌─ PAIN ─────────────┐  ┌─ COPILOT ─────────────────────────────┐   │
│  │ • Yuki GL in       │  │ Yuki OAuth → Supabase → 13-wk forecast│   │
│  │   spreadsheets     │  │ + KNMI/Open-Meteo weather drag        │   │
│  │ • Weather wipes    │  │ + Lovable AI CFO briefing             │   │
│  │   working days     │  │                                       │   │
│  │ • Covenant risk    │  │ €312k trough · W7 · −€186k weather    │   │
│  │   spotted too late │  │ Action: draw RCF before W7            │   │
│  └────────────────────┘  └───────────────────────────────────────┘   │
│                                                                      │
│  Demo: live scenario toggle (base / stress / adverse weather)        │
│                                                                      │
│  Team Urumchi · Ziya Alim Sungkar · Prateek Vivek Samarth ·          │
│  Abdulhabir Karahanli                                                │
└──────────────────────────────────────────────────────────────────────┘
```

### Visual style

- Palette: **Midnight Executive** — navy `#1E2761` background band for header/footer, ice-blue `#CADCFC` accent, white body, coral `#F96167` for the trough/risk number.
- Typography: Georgia headline (44pt), Calibri body (20pt), 14pt caption for footer/team.
- Two-column "Pain vs Copilot" cards with rounded rectangles, subtle border, ice-blue tint on the Copilot card to signal it's the answer.
- One stat callout in the Copilot card (`€312k · W7` at ~40pt coral) so a glance reads the punchline.
- Bottom strip: thin navy bar with team names + a small "Built on Lovable Cloud + Yuki + Open-Meteo" tag.

### Build steps

1. `bun add -d pptxgenjs` (devDependency; only used by the build script).
2. Write `scripts/build-pitch-slide.ts` that constructs the slide above with pptxgenjs and writes to `/mnt/documents/urumchi_pitch.pptx`.
3. Run it with `bun run scripts/build-pitch-slide.ts`.
4. QA: convert to PDF with the bundled LibreOffice helper, render to JPG, inspect for overflow / contrast / alignment, fix and re-render until clean.
5. Emit `<presentation-artifact path="urumchi_pitch.pptx" mime_type="application/vnd.openxmlformats-officedocument.presentationml.presentation"></presentation-artifact>` so you can download it.

### Out of scope

- No in-app `/pitch` route, no app code changes, no backend changes.
- No appendix/backup slides (single hero slide as requested).
- No real Altis logo (use a typographic wordmark to avoid trademark issues).

### Open question

The numbers on the slide (`€312k trough · W7 · −€186k weather`) are illustrative, taken from the existing CFO Summary mock. If you want me to instead compute them live from `altis.json` at build time and bake the actual base-scenario figures into the slide, say so and I'll wire that in — otherwise I'll use the illustrative figures above so the slide reads cleanly during the live pitch.
